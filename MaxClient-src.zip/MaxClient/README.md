# MAX CLIENT (Forge 1.12.2)

Чёрно-фиолетовый клиентский мод: ClickGUI, Hitboxes, X-Ray (подсветка руд), HUD, TriggerBot, Fullbright, Sprint, NoFall, Auto Tool.

## Сборка
Нужен **JDK 8** (ForgeGradle 2.3 / Gradle 4.9 на Java 9+ не работают).
```
gradle wrapper --gradle-version 4.9   # один раз, создаёт gradlew
./gradlew build
```
JAR: `build/libs/MaxClient-1.0.4.jar`. На GitHub: Actions -> Build MAX CLIENT -> Artifacts.

## Установка (PojavLauncher / совместимые лаунчеры)
1. Установи Minecraft **1.12.2** + **Forge 14.23.5.2860**, в настройках профиля выбери **Java 8**.
2. Положи JAR в `<папка игры>/mods`.
3. Запусти профиль Forge.

## Управление
- **Right Shift** - открыть/закрыть меню (клавишу можно переназначить в Controls -> MAX CLIENT).
- Нет Right Shift (сенсорное управление): в чате введи `/max`.
- ЛКМ по модулю - вкл/выкл; ПКМ или клик по `+` справа - настройки. Колесо мыши - прокрутка панели.
- Настройки сохраняются в `config/maxclient.json` при закрытии меню.

Не используй на серверах, где читы запрещены.
