# MAX CLIENT (Forge 1.12.2)

Чёрно-фиолетовый клиентский мод: ClickGUI, Hitboxes, X-Ray (подсветка руд), HUD, TriggerBot, Fullbright, Sprint, NoFall, Auto Tool, Player ESP, Chest ESP.

## Сборка
Нужен **JDK 8** (ForgeGradle 2.3 / Gradle 4.9 на Java 9+ не работают).
```
gradle wrapper --gradle-version 4.9   # один раз, создаёт gradlew
./gradlew build
```
JAR: `build/libs/MaxClient-1.0.6.jar`. На GitHub: Actions -> Build MAX CLIENT -> Artifacts.

## Установка (PojavLauncher / совместимые лаунчеры)
1. Установи Minecraft **1.12.2** + **Forge 14.23.5.2860**, в настройках профиля выбери **Java 8**.
2. Положи JAR в `<папка игры>/mods`.
3. Запусти профиль Forge.

## Управление
- **Right Shift** - открыть/закрыть меню (клавишу можно переназначить в Controls -> MAX CLIENT).
- Нет Right Shift (сенсорное управление): в чате введи `/max`.
- ЛКМ по модулю - вкл/выкл; ПКМ или клик по `+` справа - настройки. Колесо мыши - прокрутка панели.
- Настройки сохраняются в `config/maxclient.json` при закрытии меню.

Не используй на серверах, где читы запрещены.

## Player ESP и друзья
Модуль в категории Render. Режимы: Box (заливка), Outline (рамка), Both. Друзья (подсвечиваются зелёным, можно скрыть настройкой Ignore Friends):
`/friend add <ник>`, `/friend remove <ник>`, `/friend list`, `/friend clear`. Список хранится в `config/maxclient.json`.

## Chest ESP и TriggerBot
Chest ESP (Render): обычные, двойные, trapped и эндер-сундуки, у каждого свой переключатель и цвет, дальность, названия.
TriggerBot: Critical hits / Normal hits (удар считается критическим, если игра сделала бы его критом), Delay (ms) - минимальная пауза между ударами.
