package com.maxclient;

import com.maxclient.config.ConfigManager;
import com.maxclient.crashtest.CrashTestNetwork;
import com.maxclient.crashtest.CrashTestServer;
import com.maxclient.friend.FriendCommand;
import com.maxclient.gui.ClickGui;
import com.maxclient.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import net.minecraftforge.fml.common.FMLCommonHandler;
import org.lwjgl.input.Keyboard;

/** Not client-only: the Crash Test server-side monitor (CrashTestServer) must also load on a dedicated server. */
@Mod(modid = MaxClient.MODID, name = MaxClient.NAME, version = MaxClient.VERSION,
        acceptedMinecraftVersions = "[1.12.2]")
public class MaxClient {
    public static final String MODID = "maxclient";
    public static final String NAME = "EXTRA CLIENT";
    public static final String VERSION = "1.0.16";
    public static final Logger LOG = LogManager.getLogger(NAME);

    public static KeyBinding openKey;
    public static KeyBinding zoomKey;
    private static boolean openRequest;

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        CrashTestNetwork.init();
        CrashTestServer.init(); // real server-tick timing only; fires for a dedicated server AND the integrated one

        if (FMLCommonHandler.instance().getSide().isClient()) {
            openKey = new KeyBinding("Open ClickGUI", Keyboard.KEY_RSHIFT, NAME);
            ClientRegistry.registerKeyBinding(openKey);
            zoomKey = new KeyBinding("Zoom", Keyboard.KEY_C, NAME);
            ClientRegistry.registerKeyBinding(zoomKey);
            ModuleManager.init();
            ConfigManager.load();
            MinecraftForge.EVENT_BUS.register(this);
            ClientCommandHandler.instance.registerCommand(new CommandBase() {
                @Override public String getName() { return "max"; }

                @Override public String getUsage(ICommandSender sender) { return "/max"; }

                @Override public int getRequiredPermissionLevel() { return 0; }

                @Override public boolean checkPermission(MinecraftServer server, ICommandSender sender) { return true; }

                @Override public void execute(MinecraftServer server, ICommandSender sender, String[] args)
                        throws CommandException {
                    openRequest = true;
                }
            });
            ClientCommandHandler.instance.registerCommand(new FriendCommand());
        }
        LOG.info("{} {} loaded ({})", NAME, VERSION, FMLCommonHandler.instance().getSide());
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        while (openKey.isPressed()) {
            if (mc.currentScreen == null) mc.displayGuiScreen(new ClickGui());
        }
    }

    /** Lets /max open the GUI after the chat screen has closed (useful without a physical Right Shift). */
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (e.phase != TickEvent.Phase.END || !openRequest || mc.currentScreen instanceof GuiChat) return;
        openRequest = false;
        if (mc.currentScreen == null) mc.displayGuiScreen(new ClickGui());
    }
}
