package com.maxclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

public class NumberSetting extends Setting {
    public final double min, max, step;
    private double value;

    public NumberSetting(String name, double def, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(def);
    }

    public double get() { return value; }

    public float getFloat() { return (float) value; }

    public int getInt() { return (int) Math.round(value); }

    public void set(double v) {
        v = Math.max(min, Math.min(max, v));
        v = min + Math.round((v - min) / step) * step;
        value = Math.max(min, Math.min(max, v));
    }

    public String display() {
        int d = step >= 1 ? 0 : step >= 0.1 ? 1 : 2;
        return String.format(Locale.ROOT, "%." + d + "f", value);
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) { set(e.getAsDouble()); }
}
