package com.maxclient.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import net.minecraft.util.math.MathHelper;

public class ColorSetting extends Setting {
    private float hue, sat;

    public ColorSetting(String name, float hue, float sat) {
        super(name);
        this.hue = hue;
        this.sat = sat;
    }

    public float getHue() { return hue; }

    public float getSat() { return sat; }

    public void setHue(float h) { hue = Math.max(0f, Math.min(1f, h)); }

    public void setSat(float s) { sat = Math.max(0f, Math.min(1f, s)); }

    /** RGB without alpha. */
    public int getRGB() { return MathHelper.hsvToRGB(hue, sat, 1f) & 0xFFFFFF; }

    @Override public JsonElement toJson() {
        JsonArray a = new JsonArray();
        a.add(new com.google.gson.JsonPrimitive(hue));
        a.add(new com.google.gson.JsonPrimitive(sat));
        return a;
    }

    @Override public void fromJson(JsonElement e) {
        JsonArray a = e.getAsJsonArray();
        setHue(a.get(0).getAsFloat());
        setSat(a.get(1).getAsFloat());
    }
}
