package com.maxclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** A setting with a fixed list of named options; the ClickGUI cycles through them on click. */
public class ModeSetting extends Setting {
    private final String[] options;
    private int index;

    public ModeSetting(String name, int def, String... options) {
        super(name);
        this.options = options;
        this.index = Math.max(0, Math.min(options.length - 1, def));
    }

    public String get() { return options[index]; }

    public int getIndex() { return index; }

    public void next() { index = (index + 1) % options.length; }

    public void prev() { index = (index + options.length - 1) % options.length; }

    @Override public JsonElement toJson() { return new JsonPrimitive(options[index]); }

    @Override public void fromJson(JsonElement e) {
        String v = e.getAsString();
        for (int i = 0; i < options.length; i++) {
            if (options[i].equalsIgnoreCase(v)) {
                index = i;
                return;
            }
        }
    }
}
