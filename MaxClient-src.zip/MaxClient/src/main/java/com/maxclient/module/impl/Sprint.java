package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player.moveForward > 0 && !mc.player.isSneaking() && !mc.player.collidedHorizontally
                && !mc.player.isHandActive() && mc.player.getFoodStats().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
