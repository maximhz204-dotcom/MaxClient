package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.NumberSetting;
import net.minecraft.client.gui.ScaledResolution;

/** Base for single-line HUD elements. */
public abstract class TextHud extends Module {
    private final ColorSetting color;
    private final BoolSetting shadow;
    private final NumberSetting posX, posY;

    protected TextHud(String name, int x, int y) {
        super(name, Category.HUD);
        color = add(new ColorSetting("Color", 0.76f, 0.6f));
        shadow = add(new BoolSetting("Shadow", true));
        posX = add(new NumberSetting("X", x, 0, 600, 1));
        posY = add(new NumberSetting("Y", y, 0, 400, 1));
        enabledByDefault();
    }

    protected abstract String text();

    @Override
    public void onRender2D(ScaledResolution sr) {
        mc.fontRenderer.drawString(text(), posX.getFloat(), posY.getFloat(), 0xFF000000 | color.getRGB(), shadow.get());
    }
}
