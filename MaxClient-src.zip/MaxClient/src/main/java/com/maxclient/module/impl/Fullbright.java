package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;

/** Client-side night vision effect. */
public class Fullbright extends Module {
    public Fullbright() {
        super("Fullbright", Category.RENDER);
    }

    @Override
    public void onTick() {
        PotionEffect e = mc.player.getActivePotionEffect(MobEffects.NIGHT_VISION);
        if (e == null || e.getDuration() < 400) {
            mc.player.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 1000, 0, false, false));
        }
    }

    @Override
    protected void onDisable() {
        if (mc.player != null) mc.player.removePotionEffect(MobEffects.NIGHT_VISION);
    }
}
