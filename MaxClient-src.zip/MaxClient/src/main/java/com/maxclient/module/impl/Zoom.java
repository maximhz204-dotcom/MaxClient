package com.maxclient.module.impl;

import com.maxclient.MaxClient;
import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.NumberSetting;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Reduces the real field of view while the Zoom key is held - uses vanilla's own FOV pipeline, nothing faked. */
public class Zoom extends Module {
    private final NumberSetting level = add(new NumberSetting("Zoom level", 4, 1.5, 8, 0.5));

    public Zoom() {
        super("Zoom", Category.RENDER);
        enabledByDefault();
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onFov(FOVUpdateEvent e) {
        if (isEnabled() && MaxClient.zoomKey != null && MaxClient.zoomKey.isKeyDown()) {
            e.setNewfov(e.getFov() / level.getFloat());
        }
    }
}
