package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;

/** Attacks the entity under the crosshair once the attack cooldown is ready. */
public class TriggerBot extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    private final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.95, 0.5, 1.0, 0.05));

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.objectMouseOver == null
                || mc.objectMouseOver.typeOfHit != RayTraceResult.Type.ENTITY) return;
        Entity t = mc.objectMouseOver.entityHit;
        if (!(t instanceof EntityLivingBase) || t instanceof EntityArmorStand || !t.isEntityAlive()) return;
        if (t instanceof EntityPlayer ? !players.get() : !mobs.get()) return;
        if (mc.player.getCooledAttackStrength(0f) < cooldown.getFloat()) return;
        mc.playerController.attackEntity(mc.player, t);
        mc.player.swingArm(EnumHand.MAIN_HAND);
    }
}
