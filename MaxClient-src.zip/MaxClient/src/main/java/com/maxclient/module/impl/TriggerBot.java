package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;

/**
 * Attacks the entity under the crosshair once the attack cooldown is ready. A hit counts as critical when
 * vanilla would make it one (falling, not on ground/ladder/water, not sprinting, not blind, not riding,
 * cooldown above 0.9); every other hit is a normal hit. Each kind can be switched off separately.
 */
public class TriggerBot extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    private final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.95, 0.5, 1.0, 0.05));
    private final BoolSetting crits = add(new BoolSetting("Critical hits", true));
    private final BoolSetting normal = add(new BoolSetting("Normal hits", true));
    private final NumberSetting delay = add(new NumberSetting("Delay (ms)", 0, 0, 500, 10));
    private long lastAttack;

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.objectMouseOver == null
                || mc.objectMouseOver.typeOfHit != RayTraceResult.Type.ENTITY) return;
        Entity t = mc.objectMouseOver.entityHit;
        if (!(t instanceof EntityLivingBase) || t instanceof EntityArmorStand || !t.isEntityAlive()) return;
        if (t instanceof EntityPlayer ? !players.get() : !mobs.get()) return;
        float strength = mc.player.getCooledAttackStrength(0.5f);
        if (strength < cooldown.getFloat()) return;
        boolean crit = strength > 0.9f && canCrit();
        if (crit ? !crits.get() : !normal.get()) return;
        long now = System.currentTimeMillis();
        if (now - lastAttack < delay.getInt()) return;
        lastAttack = now;
        mc.playerController.attackEntity(mc.player, t);
        mc.player.swingArm(EnumHand.MAIN_HAND);
    }

    /** Same conditions the game checks when a player attacks a living entity. */
    private boolean canCrit() {
        return mc.player.fallDistance > 0f && !mc.player.onGround && !mc.player.isOnLadder()
                && !mc.player.isInWater() && !mc.player.isPotionActive(MobEffects.BLINDNESS)
                && !mc.player.isRiding() && !mc.player.isSprinting();
    }
}
