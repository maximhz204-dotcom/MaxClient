package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;

/** Suppresses the damage head-tilt by keeping the vanilla hurtTime timer at zero while enabled. */
public class NoHurtCam extends Module {
    public NoHurtCam() {
        super("БезТряски", Category.RENDER);
    }

    @Override
    public void onTick() {
        mc.player.hurtTime = 0;
    }
}
