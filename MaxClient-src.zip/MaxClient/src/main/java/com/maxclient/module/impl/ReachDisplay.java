package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.math.RayTraceResult;

import java.util.Locale;

/** Real distance from your eyes to whatever the crosshair is on - block or entity, straight from the raytrace. */
public class ReachDisplay extends Module {
    public ReachDisplay() {
        super("Дистанция", Category.COMBAT);
        enabledByDefault();
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        RayTraceResult r = mc.objectMouseOver;
        if (r == null || r.typeOfHit == RayTraceResult.Type.MISS || r.hitVec == null) return;
        double d = mc.player.getPositionEyes(1f).distanceTo(r.hitVec);
        String text = String.format(Locale.ROOT, "%.2f m", d);
        int x = sr.getScaledWidth() / 2 - mc.fontRenderer.getStringWidth(text) / 2;
        int y = sr.getScaledHeight() / 2 + 10;
        mc.fontRenderer.drawString(text, x, y, 0xFFEEE6FF, true);
    }
}
