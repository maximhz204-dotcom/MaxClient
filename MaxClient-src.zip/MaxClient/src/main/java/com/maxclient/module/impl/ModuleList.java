package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.module.ModuleManager;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.NumberSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.FontRenderer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Active modules list, right-aligned, sorted by width. */
public class ModuleList extends Module {
    private final ColorSetting color = add(new ColorSetting("Color", 0.76f, 0.85f));
    private final BoolSetting background = add(new BoolSetting("Background", true));
    private final BoolSetting shadow = add(new BoolSetting("Shadow", true));
    private final NumberSetting posY = add(new NumberSetting("Y", 2, 0, 300, 1));

    public ModuleList() {
        super("Module list", Category.HUD);
        enabledByDefault();
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        final FontRenderer fr = mc.fontRenderer;
        List<String> names = new ArrayList<>();
        for (Module m : ModuleManager.all()) if (m.isEnabled() && m.category != Category.HUD) names.add(m.name);
        Collections.sort(names, new Comparator<String>() {
            @Override public int compare(String a, String b) {
                return Integer.compare(fr.getStringWidth(b), fr.getStringWidth(a));
            }
        });
        int rgb = 0xFF000000 | color.getRGB();
        int right = sr.getScaledWidth();
        int y = posY.getInt();
        for (String n : names) {
            int x = right - fr.getStringWidth(n) - 6;
            if (background.get()) Gui.drawRect(x - 2, y, right, y + 11, 0x90000000);
            Gui.drawRect(right - 2, y, right, y + 11, rgb);
            fr.drawString(n, x, y + 2, rgb, shadow.get());
            y += 11;
        }
    }
}
