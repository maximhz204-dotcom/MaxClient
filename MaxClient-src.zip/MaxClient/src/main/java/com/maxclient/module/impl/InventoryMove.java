package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import net.minecraft.client.gui.inventory.GuiContainer;

/**
 * Lets you keep walking with WASD/jump/sneak while an inventory-style screen (your inventory, a chest, a
 * furnace...) is open. It only feeds the game's own MovementInput fields from the real key state every tick
 * while such a screen is open; mouse clicks inside the GUI still work normally since the mouse is untouched.
 */
public class InventoryMove extends Module {
    public InventoryMove() {
        super("Инвентарь-ходьба", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (!(mc.currentScreen instanceof GuiContainer) || mc.player == null) return;
        mc.player.movementInput.moveForward = (mc.gameSettings.keyBindForward.isKeyDown() ? 1f : 0f)
                - (mc.gameSettings.keyBindBack.isKeyDown() ? 1f : 0f);
        mc.player.movementInput.moveStrafe = (mc.gameSettings.keyBindRight.isKeyDown() ? 1f : 0f)
                - (mc.gameSettings.keyBindLeft.isKeyDown() ? 1f : 0f);
        mc.player.movementInput.jump = mc.gameSettings.keyBindJump.isKeyDown();
        mc.player.movementInput.sneak = mc.gameSettings.keyBindSneak.isKeyDown();
    }
}
