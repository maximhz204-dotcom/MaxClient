package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.NumberSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Mouse;

/** Real WASD + mouse-button state, read straight from the game's own key bindings and LWJGL mouse state. */
public class KeystrokesHud extends Module {
    private final NumberSetting posX = add(new NumberSetting("X", 6, 0, 600, 1));
    private final NumberSetting posY = add(new NumberSetting("Y", 140, 0, 400, 1));

    public KeystrokesHud() {
        super("Клавиши", Category.HUD);
        enabledByDefault();
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        int x = posX.getInt(), y = posY.getInt(), s = 18;
        GlStateManager.enableBlend();
        key(x + s + 2, y, s, mc.gameSettings.keyBindForward.isKeyDown(), "W");
        key(x, y + s + 2, s, mc.gameSettings.keyBindLeft.isKeyDown(), "A");
        key(x + s + 2, y + s + 2, s, mc.gameSettings.keyBindBack.isKeyDown(), "S");
        key(x + 2 * s + 4, y + s + 2, s, mc.gameSettings.keyBindRight.isKeyDown(), "D");
        key(x, y + 2 * s + 4, s, Mouse.isButtonDown(0), "L");
        key(x + s + 2, y + 2 * s + 4, s, mc.gameSettings.keyBindJump.isKeyDown(), "SP");
        key(x + 2 * s + 4, y + 2 * s + 4, s, Mouse.isButtonDown(1), "R");
    }

    private void key(int x, int y, int s, boolean down, String label) {
        Gui.drawRect(x, y, x + s, y + s, down ? 0xC09B30FF : 0x90000000);
        int w = mc.fontRenderer.getStringWidth(label);
        mc.fontRenderer.drawString(label, x + (s - w) / 2, y + (s - 8) / 2, 0xFFFFFFFF, true);
    }
}
