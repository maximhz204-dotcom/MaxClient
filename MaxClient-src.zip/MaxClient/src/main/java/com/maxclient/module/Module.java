package com.maxclient.module;

import com.maxclient.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected final Minecraft mc = Minecraft.getMinecraft();
    public final String name;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected <T extends Setting> T add(T s) {
        settings.add(s);
        return s;
    }

    /** For modules that start enabled; does not call onEnable. */
    protected void enabledByDefault() { enabled = true; }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    public void toggle() { setEnabled(!enabled); }

    protected void onEnable() {}

    protected void onDisable() {}

    /** Called every client tick while in a world. */
    public void onTick() {}

    /** Called after world rendering (world-space drawing). */
    public void onRender3D(float partialTicks) {}

    /** Called at the start of every rendered frame, before the game computes what the crosshair points at. */
    public void onRenderStart(float partialTicks) {}

    /** Called at the end of every rendered frame (always, also for disabled modules; undo onRenderStart here). */
    public void onRenderEnd() {}

    /** Called after the in-game overlay. */
    public void onRender2D(ScaledResolution sr) {}
}
