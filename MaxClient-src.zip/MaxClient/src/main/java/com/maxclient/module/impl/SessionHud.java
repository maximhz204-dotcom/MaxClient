package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.NumberSetting;
import net.minecraft.client.gui.ScaledResolution;

import java.util.Locale;

/** Real, locally-measured session stats: how long this world/session has been open and the current dimension. */
public class SessionHud extends Module {
    private final NumberSetting posX = add(new NumberSetting("X", 6, 0, 600, 1));
    private final NumberSetting posY = add(new NumberSetting("Y", 340, 0, 400, 1));
    private long startedAt = -1;

    public SessionHud() {
        super("Сессия", Category.HUD);
        enabledByDefault();
    }

    @Override
    public void onTick() {
        if (startedAt < 0) startedAt = System.currentTimeMillis();
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        if (startedAt < 0) return;
        long sec = (System.currentTimeMillis() - startedAt) / 1000;
        String line = String.format(Locale.ROOT, "Session: %d:%02d  Dim: %d", sec / 60, sec % 60,
                mc.player.dimension);
        mc.fontRenderer.drawString(line, posX.getFloat(), posY.getFloat(), 0xFFEEE6FF, true);
    }
}
