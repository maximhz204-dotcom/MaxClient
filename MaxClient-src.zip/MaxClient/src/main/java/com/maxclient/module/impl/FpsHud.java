package com.maxclient.module.impl;

import net.minecraft.client.Minecraft;

public class FpsHud extends TextHud {
    public FpsHud() {
        super("FPS", 4, 4);
    }

    @Override
    protected String text() {
        return "FPS: " + Minecraft.getDebugFPS();
    }
}
