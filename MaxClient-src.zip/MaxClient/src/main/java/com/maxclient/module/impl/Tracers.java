package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;

/** A real line from your eyes to each nearby player/mob - uses their actual render position, nothing guessed. */
public class Tracers extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    private final NumberSetting maxDistance = add(new NumberSetting("Maximum Distance", 48, 8, 128, 4));
    private final ColorSetting color = add(new ColorSetting("Color", 0.76f, 0.85f));
    private final NumberSetting lineWidth = add(new NumberSetting("Line width", 1, 1, 4, 0.5));

    public Tracers() {
        super("Трейсеры", Category.RENDER);
    }

    @Override
    public void onRender3D(float pt) {
        float max = maxDistance.getFloat();
        int rgb = color.getRGB();
        RenderUtil.begin3D(pt, lineWidth.getFloat());
        RenderUtil.beginLines();
        double ex = mc.player.lastTickPosX + (mc.player.posX - mc.player.lastTickPosX) * pt;
        double ey = mc.player.lastTickPosY + (mc.player.posY - mc.player.lastTickPosY) * pt + mc.player.getEyeHeight();
        double ez = mc.player.lastTickPosZ + (mc.player.posZ - mc.player.lastTickPosZ) * pt;
        for (Entity e : mc.world.loadedEntityList) {
            if (!(e instanceof EntityLivingBase) || e == mc.player || e instanceof EntityArmorStand || e.isDead
                    || mc.player.getDistance(e) > max) {
                continue;
            }
            if (e instanceof EntityPlayer) {
                if (!players.get()) continue;
            } else if (!mobs.get()) {
                continue;
            }
            double tx = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt;
            double ty = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt + e.height / 2f;
            double tz = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt;
            RenderUtil.line(ex, ey, ez, tx, ty, tz, rgb, 255);
        }
        RenderUtil.endBatch();
        RenderUtil.end3D();
    }
}
