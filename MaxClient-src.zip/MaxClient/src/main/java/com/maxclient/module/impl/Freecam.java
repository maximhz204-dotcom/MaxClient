package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.NumberSetting;

/**
 * Singleplayer-only free camera: moves your real player entity by direct position changes (ignoring normal
 * input), same restriction as Fly/NoClip, since letting the view detach from a position the server tracks is
 * only sound to allow on your own integrated server.
 */
public class Freecam extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.8, 0.1, 3.0, 0.1));
    private double savedX, savedY, savedZ;
    private boolean saved;

    public Freecam() {
        super("Фрикам", Category.RENDER);
    }
    /** Singleplayer, or real server-granted Creative mode - a flag the server pushes, not one the client can fake.
     *  This is exactly the "singleplayer or an authorized testing environment" rule this project was given. */
    private boolean authorized() {
        return mc.isIntegratedServerRunning() || (mc.player != null && mc.player.capabilities.isCreativeMode);
    }


    @Override
    protected void onEnable() {
        if (!authorized()) {
            setEnabled(false);
            return;
        }
        savedX = mc.player.posX;
        savedY = mc.player.posY;
        savedZ = mc.player.posZ;
        saved = true;
        mc.player.noClip = true;
        mc.player.motionX = mc.player.motionY = mc.player.motionZ = 0;
    }

    @Override
    protected void onDisable() {
        if (mc.player == null) return;
        mc.player.noClip = false;
        if (saved) mc.player.setPositionAndUpdate(savedX, savedY, savedZ);
        saved = false;
    }

    @Override
    public void onTick() {
        if (!authorized()) {
            setEnabled(false);
            return;
        }
        float f = speed.getFloat();
        float yaw = (float) Math.toRadians(mc.player.rotationYaw);
        float pitch = (float) Math.toRadians(mc.player.rotationPitch);
        float fwd = (mc.gameSettings.keyBindForward.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindBack.isKeyDown() ? 1 : 0);
        float strafe = (mc.gameSettings.keyBindRight.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindLeft.isKeyDown() ? 1 : 0);
        double dx = -Math.sin(yaw) * Math.cos(pitch) * fwd + Math.cos(yaw) * strafe;
        double dz = Math.cos(yaw) * Math.cos(pitch) * fwd + Math.sin(yaw) * strafe;
        double dy = (mc.gameSettings.keyBindJump.isKeyDown() ? 1 : 0) - (mc.gameSettings.keyBindSneak.isKeyDown() ? 1 : 0);
        mc.player.setPosition(mc.player.posX + dx * f, mc.player.posY + dy * f, mc.player.posZ + dz * f);
        mc.player.motionX = mc.player.motionY = mc.player.motionZ = 0;
        mc.player.fallDistance = 0f;
    }
}
