package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;

/** Your own equipped armor with real, live durability percentages (no invented numbers). */
public class ArmorHud extends Module {
    private static final EntityEquipmentSlot[] SLOTS = {EntityEquipmentSlot.HEAD, EntityEquipmentSlot.CHEST,
            EntityEquipmentSlot.LEGS, EntityEquipmentSlot.FEET};
    private static final int ICON = 16;

    private final NumberSetting posX = add(new NumberSetting("X", 6, 0, 600, 1));
    private final NumberSetting posY = add(new NumberSetting("Y", 260, 0, 400, 1));
    private final BoolSetting durability = add(new BoolSetting("Show %", true));

    public ArmorHud() {
        super("Броня", Category.HUD);
        enabledByDefault();
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        int x = posX.getInt(), y = posY.getInt();
        GlStateManager.enableBlend();
        Gui.drawRect(x - 2, y - 2, x + SLOTS.length * (ICON + 2) + 2, y + ICON + (durability.get() ? 10 : 2),
                0x80000000);
        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack s = mc.player.getItemStackFromSlot(SLOTS[i]);
            int sx = x + i * (ICON + 2);
            if (s.isEmpty()) continue;
            GlStateManager.pushMatrix();
            GlStateManager.translate(sx, y, 0f);
            RenderHelper.enableGUIStandardItemLighting();
            mc.getRenderItem().renderItemAndEffectIntoGUI(s, 0, 0);
            RenderHelper.disableStandardItemLighting();
            GlStateManager.popMatrix();
            if (durability.get() && s.isItemStackDamageable()) {
                int pct = Math.round(100f * (s.getMaxDamage() - s.getItemDamage()) / s.getMaxDamage());
                int color = pct >= 70 ? 0xFF55FF88 : pct >= 30 ? 0xFFFFD24C : 0xFFFF5555;
                String t = pct + "%";
                mc.fontRenderer.drawString(t, sx + (ICON - mc.fontRenderer.getStringWidth(t)) / 2f, y + ICON + 1,
                        color, true);
            }
        }
    }
}
