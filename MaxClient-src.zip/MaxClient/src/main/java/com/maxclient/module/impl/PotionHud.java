package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.NumberSetting;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.resources.I18n;
import net.minecraft.potion.PotionEffect;

import java.util.Locale;

/** Your real active potion effects and their real remaining duration, straight from the entity. */
public class PotionHud extends Module {
    private final NumberSetting posX = add(new NumberSetting("X", 6, 0, 600, 1));
    private final NumberSetting posY = add(new NumberSetting("Y", 300, 0, 400, 1));

    public PotionHud() {
        super("Эффекты", Category.HUD);
        enabledByDefault();
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        int y = posY.getInt();
        for (PotionEffect e : mc.player.getActivePotionEffects()) {
            int sec = e.getDuration() / 20;
            String line = I18n.format(e.getEffectName()) + (e.getAmplifier() > 0 ? " " + (e.getAmplifier() + 1) : "")
                    + String.format(Locale.ROOT, " %d:%02d", sec / 60, sec % 60);
            mc.fontRenderer.drawString(line, posX.getFloat(), y, 0xFFEEE6FF, true);
            y += 10;
        }
    }
}
