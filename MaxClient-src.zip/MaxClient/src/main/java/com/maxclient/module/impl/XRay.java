package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Ore highlighter: scans blocks around the player and draws boxes through walls. */
public class XRay extends Module {
    private static final int MAX_HITS = 5000, LAYERS_PER_TICK = 6;

    private static final class Hit {
        final BlockPos pos;
        final Block block;

        Hit(BlockPos pos, Block block) {
            this.pos = pos;
            this.block = block;
        }
    }

    private final NumberSetting range = add(new NumberSetting("Range", 24, 8, 48, 4));
    private final NumberSetting fill = add(new NumberSetting("Fill alpha", 40, 0, 120, 5));
    private final NumberSetting lineWidth = add(new NumberSetting("Line width", 1.5, 1, 4, 0.5));
    private final Map<Block, BoolSetting> toggles = new HashMap<>();
    private final Map<Block, Integer> colors = new HashMap<>();
    private List<Hit> hits = new ArrayList<>();
    private List<Hit> pending = new ArrayList<>();
    private boolean scanning;
    private int scanX, cx, cy, cz, scanR;

    public XRay() {
        super("X-Ray", Category.RENDER);
        ore("Coal", 0xA0A0A0, Blocks.COAL_ORE);
        ore("Iron", 0xD8AF93, Blocks.IRON_ORE);
        ore("Gold", 0xFFD700, Blocks.GOLD_ORE);
        ore("Lapis", 0x2F5BFF, Blocks.LAPIS_ORE);
        ore("Redstone", 0xFF1E1E, Blocks.REDSTONE_ORE, Blocks.LIT_REDSTONE_ORE);
        ore("Diamond", 0x2EF0F0, Blocks.DIAMOND_ORE);
        ore("Emerald", 0x1EE05A, Blocks.EMERALD_ORE);
        ore("Quartz", 0xF5F0E6, Blocks.QUARTZ_ORE);
    }

    private void ore(String name, int color, Block... blocks) {
        BoolSetting s = add(new BoolSetting(name, true));
        for (Block b : blocks) {
            toggles.put(b, s);
            colors.put(b, color);
        }
    }

    @Override
    protected void onEnable() {
        scanning = false;
        hits = new ArrayList<>();
        pending = new ArrayList<>();
    }

    @Override
    protected void onDisable() {
        hits = new ArrayList<>();
        pending = new ArrayList<>();
        scanning = false;
    }

    @Override
    public void onTick() {
        for (int i = 0; i < LAYERS_PER_TICK; i++) {
            if (!scanning) {
                scanning = true;
                cx = (int) Math.floor(mc.player.posX);
                cy = (int) Math.floor(mc.player.posY);
                cz = (int) Math.floor(mc.player.posZ);
                scanR = range.getInt();
                scanX = cx - scanR;
                pending = new ArrayList<>();
            }
            scanLayer();
            if (scanX > cx + scanR) {
                hits = pending;
                pending = new ArrayList<>();
                scanning = false;
                return;
            }
        }
    }

    private void scanLayer() {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int y0 = Math.max(0, cy - scanR), y1 = Math.min(255, cy + scanR);
        for (int z = cz - scanR; z <= cz + scanR; z++) {
            for (int y = y0; y <= y1; y++) {
                p.setPos(scanX, y, z);
                Block b = mc.world.getBlockState(p).getBlock();
                if (toggles.containsKey(b) && pending.size() < MAX_HITS) pending.add(new Hit(p.toImmutable(), b));
            }
        }
        scanX++;
    }

    @Override
    public void onRender3D(float pt) {
        if (hits.isEmpty()) return;
        RenderUtil.begin3D(pt, lineWidth.getFloat());
        for (Hit h : hits) {
            if (!toggles.get(h.block).get() || mc.world.getBlockState(h.pos).getBlock() != h.block) continue;
            RenderUtil.box(new AxisAlignedBB(h.pos).grow(0.002), colors.get(h.block), fill.getInt(), 255);
        }
        RenderUtil.end3D();
    }
}
