package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Ore highlighter: scans loaded blocks around the player (a few layers per tick) and draws boxes through
 * walls. Nothing in vanilla block/chunk rendering is touched, so textures, lighting and chunk updates stay
 * vanilla. The nearest ores are always kept, and every box is validated against the live world each frame.
 */
public class XRay extends Module {
    private static final int MAX_HITS = 4000, MAX_PENDING = 60000, LAYERS_PER_TICK = 6;

    private static final class Hit {
        final BlockPos pos;
        final int dist;

        Hit(BlockPos pos, int dist) {
            this.pos = pos;
            this.dist = dist;
        }
    }

    private final NumberSetting range = add(new NumberSetting("Range", 24, 8, 48, 4));
    private final NumberSetting fill = add(new NumberSetting("Fill alpha", 40, 0, 120, 5));
    private final NumberSetting lineWidth = add(new NumberSetting("Line width", 1.5, 1, 4, 0.5));
    private final Map<Block, BoolSetting> toggles = new HashMap<>();
    private final Map<Block, Integer> colors = new HashMap<>();
    private List<Hit> hits = new ArrayList<>();
    private List<Hit> pending = new ArrayList<>();
    private World lastWorld;
    private boolean scanning;
    private int scanX, cx, cy, cz, scanR;

    public XRay() {
        super("X-Ray", Category.RENDER);
        ore("Coal", 0xA0A0A0, Blocks.COAL_ORE);
        ore("Iron", 0xD8AF93, Blocks.IRON_ORE);
        ore("Gold", 0xFFD700, Blocks.GOLD_ORE);
        ore("Lapis", 0x2F5BFF, Blocks.LAPIS_ORE);
        ore("Redstone", 0xFF1E1E, Blocks.REDSTONE_ORE, Blocks.LIT_REDSTONE_ORE);
        ore("Diamond", 0x2EF0F0, Blocks.DIAMOND_ORE);
        ore("Emerald", 0x1EE05A, Blocks.EMERALD_ORE);
        ore("Quartz", 0xF5F0E6, Blocks.QUARTZ_ORE);
    }

    private void ore(String name, int color, Block... blocks) {
        BoolSetting s = add(new BoolSetting(name, true));
        for (Block b : blocks) {
            toggles.put(b, s);
            colors.put(b, color);
        }
    }

    private void reset() {
        hits = new ArrayList<>();
        pending = new ArrayList<>();
        scanning = false;
    }

    @Override
    protected void onEnable() { reset(); }

    @Override
    protected void onDisable() { reset(); }

    @Override
    public void onTick() {
        if (mc.world != lastWorld) {
            lastWorld = mc.world;
            reset();
        }
        for (int i = 0; i < LAYERS_PER_TICK; i++) {
            if (!scanning) {
                scanning = true;
                cx = (int) Math.floor(mc.player.posX);
                cy = (int) Math.floor(mc.player.posY);
                cz = (int) Math.floor(mc.player.posZ);
                scanR = range.getInt();
                scanX = cx - scanR;
                pending = new ArrayList<>();
            }
            scanLayer();
            if (scanX > cx + scanR) {
                finishScan();
                return;
            }
        }
    }

    private void scanLayer() {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int y0 = Math.max(0, cy - scanR), y1 = Math.min(255, cy + scanR);
        int dx = scanX - cx;
        for (int z = cz - scanR; z <= cz + scanR; z++) {
            for (int y = y0; y <= y1; y++) {
                p.setPos(scanX, y, z);
                BoolSetting t = toggles.get(mc.world.getBlockState(p).getBlock());
                if (t != null && t.get() && pending.size() < MAX_PENDING) {
                    int dy = y - cy, dz = z - cz;
                    pending.add(new Hit(p.toImmutable(), dx * dx + dy * dy + dz * dz));
                }
            }
        }
        scanX++;
    }

    /** Keeps the MAX_HITS ores closest to the scan center, so nearby ores never get dropped. */
    private void finishScan() {
        Collections.sort(pending, new Comparator<Hit>() {
            @Override public int compare(Hit a, Hit b) {
                return Integer.compare(a.dist, b.dist);
            }
        });
        if (pending.size() > MAX_HITS) pending = new ArrayList<>(pending.subList(0, MAX_HITS));
        hits = pending;
        pending = new ArrayList<>();
        scanning = false;
    }

    @Override
    public void onRender3D(float pt) {
        int total = hits.size();
        if (total == 0) return;
        BlockPos[] pos = new BlockPos[total];
        int[] col = new int[total];
        int n = 0;
        for (Hit h : hits) {
            Block cur = mc.world.getBlockState(h.pos).getBlock();
            BoolSetting t = toggles.get(cur);
            if (t == null || !t.get()) continue;
            pos[n] = h.pos;
            col[n++] = colors.get(cur);
        }
        if (n == 0) return;
        final double e = 0.002;
        RenderUtil.begin3D(pt, lineWidth.getFloat());
        int fa = fill.getInt();
        if (fa > 0) {
            RenderUtil.beginQuads();
            for (int i = 0; i < n; i++) {
                BlockPos b = pos[i];
                RenderUtil.quadBox(b.getX() - e, b.getY() - e, b.getZ() - e, b.getX() + 1 + e, b.getY() + 1 + e,
                        b.getZ() + 1 + e, col[i], fa);
            }
            RenderUtil.endBatch();
        }
        RenderUtil.beginLines();
        for (int i = 0; i < n; i++) {
            BlockPos b = pos[i];
            RenderUtil.lineBox(b.getX() - e, b.getY() - e, b.getZ() - e, b.getX() + 1 + e, b.getY() + 1 + e,
                    b.getZ() + 1 + e, col[i], 255);
        }
        RenderUtil.endBatch();
        RenderUtil.end3D();
    }
}
