package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.NumberSetting;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.item.ItemStack;

/** Real durability of the item you're currently holding. */
public class DurabilityHud extends Module {
    private final NumberSetting posX = add(new NumberSetting("X", 6, 0, 600, 1));
    private final NumberSetting posY = add(new NumberSetting("Y", 320, 0, 400, 1));

    public DurabilityHud() {
        super("Durability", Category.HUD);
        enabledByDefault();
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        ItemStack s = mc.player.getHeldItemMainhand();
        if (s.isEmpty() || !s.isItemStackDamageable()) return;
        int pct = Math.round(100f * (s.getMaxDamage() - s.getItemDamage()) / s.getMaxDamage());
        int color = pct >= 70 ? 0xFF55FF88 : pct >= 30 ? 0xFFFFD24C : 0xFFFF5555;
        mc.fontRenderer.drawString(s.getDisplayName() + " " + pct + "%", posX.getFloat(), posY.getFloat(), color, true);
    }
}
