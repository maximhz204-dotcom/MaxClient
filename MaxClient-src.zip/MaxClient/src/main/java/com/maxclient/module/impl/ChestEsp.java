package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockChest;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Chest ESP for the 1.12.2 chest blocks: chest, double chest, trapped chest and ender chest. Chests are found
 * through the loaded tile entities, drawn through walls with the real block shape, and a double chest is
 * detected exactly like vanilla does (same block, same facing, side by side) and drawn as one box.
 */
public class ChestEsp extends Module {
    private final BoolSetting chests = add(new BoolSetting("Chests", true));
    private final ColorSetting chestColor = add(new ColorSetting("Chest color", 0.08f, 0.9f));
    private final BoolSetting doubles = add(new BoolSetting("Double chests", true));
    private final ColorSetting doubleColor = add(new ColorSetting("Double color", 0.14f, 0.9f));
    private final BoolSetting trapped = add(new BoolSetting("Trapped chests", true));
    private final ColorSetting trappedColor = add(new ColorSetting("Trapped color", 0.0f, 0.85f));
    private final BoolSetting ender = add(new BoolSetting("Ender chests", true));
    private final ColorSetting enderColor = add(new ColorSetting("Ender color", 0.78f, 0.8f));
    private final NumberSetting maxDistance = add(new NumberSetting("Maximum Distance", 64, 8, 128, 4));
    private final BoolSetting names = add(new BoolSetting("Show Names", true));
    private final BoolSetting distance = add(new BoolSetting("Show Distance", false));
    private final NumberSetting lineWidth = add(new NumberSetting("Line width", 1.5, 1, 4, 0.5));
    private final NumberSetting fill = add(new NumberSetting("Fill alpha", 40, 0, 120, 5));
    private final NumberSetting textSize = add(new NumberSetting("Text size", 1.0, 0.5, 2.0, 0.1));

    private static final class Entry {
        final AxisAlignedBB bb;
        final int rgb;
        final String name;
        final double dist;

        Entry(AxisAlignedBB bb, int rgb, String name, double dist) {
            this.bb = bb;
            this.rgb = rgb;
            this.name = name;
            this.dist = dist;
        }
    }

    public ChestEsp() {
        super("Chest ESP", Category.RENDER);
    }

    @Override
    public void onRender3D(float pt) {
        double max = maxDistance.get();
        double maxSq = max * max;
        List<Entry> found = new ArrayList<>();
        for (TileEntity te : mc.world.loadedTileEntityList) {
            if (te.isInvalid() || !(te instanceof TileEntityChest || te instanceof TileEntityEnderChest)) continue;
            BlockPos pos = te.getPos();
            double d = mc.player.getDistanceSq(pos);
            if (d > maxSq) continue;
            IBlockState state = mc.world.getBlockState(pos);
            Block block = state.getBlock();
            if (block == Blocks.ENDER_CHEST) {
                if (ender.get()) found.add(new Entry(shape(state, pos), enderColor.getRGB(), block.getLocalizedName(), Math.sqrt(d)));
            } else if (block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST) {
                BlockPos partner = partner(state, pos);
                boolean dbl = partner != null;
                if (dbl && pos.compareTo(partner) > 0) continue; // a double chest is drawn once, from its first half
                boolean trap = block == Blocks.TRAPPED_CHEST;
                if (trap ? !trapped.get() : (dbl ? !doubles.get() : !chests.get())) continue;
                AxisAlignedBB bb = shape(state, pos);
                if (dbl) bb = bb.union(shape(mc.world.getBlockState(partner), partner));
                String name = trap ? block.getLocalizedName() + (dbl ? " x2" : "")
                        : dbl ? I18n.format("container.chestDouble") : block.getLocalizedName();
                int rgb = trap ? trappedColor.getRGB() : dbl ? doubleColor.getRGB() : chestColor.getRGB();
                found.add(new Entry(bb, rgb, name, Math.sqrt(d)));
            }
        }
        if (found.isEmpty()) return;

        RenderUtil.begin3D(pt, lineWidth.getFloat());
        int fa = fill.getInt();
        if (fa > 0) {
            RenderUtil.beginQuads();
            for (Entry e : found) RenderUtil.quadBox(e.bb, e.rgb, fa);
            RenderUtil.endBatch();
        }
        RenderUtil.beginLines();
        for (Entry e : found) RenderUtil.lineBox(e.bb, e.rgb, 255);
        RenderUtil.endBatch();
        RenderUtil.end3D();

        if (!names.get() && !distance.get()) return;
        RenderUtil.beginText3D(pt);
        for (Entry e : found) {
            List<String> lines = new ArrayList<>();
            if (names.get()) lines.add("\u00a7f" + e.name);
            if (distance.get()) lines.add("\u00a77" + String.format(Locale.ROOT, "%.1fm", e.dist));
            RenderUtil.drawTag((e.bb.minX + e.bb.maxX) / 2.0, e.bb.maxY + 0.2, (e.bb.minZ + e.bb.maxZ) / 2.0,
                    lines.toArray(new String[0]), 0xFFFFFFFF, textSize.getFloat());
        }
        RenderUtil.end3D();
    }

    /** Real block shape in world coordinates. */
    private AxisAlignedBB shape(IBlockState state, BlockPos pos) {
        return state.getBoundingBox(mc.world, pos).offset(pos);
    }

    /** Other half of a double chest: same block and facing, next to this one along the side axis. */
    private BlockPos partner(IBlockState state, BlockPos pos) {
        EnumFacing f = state.getValue(BlockChest.FACING);
        BlockPos[] candidates = {pos.offset(f.rotateY()), pos.offset(f.rotateYCCW())};
        for (BlockPos n : candidates) {
            IBlockState ns = mc.world.getBlockState(n);
            if (ns.getBlock() == state.getBlock() && ns.getValue(BlockChest.FACING) == f) return n;
        }
        return null;
    }
}
