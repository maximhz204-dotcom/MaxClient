package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockChest;
import net.minecraft.block.BlockShulkerBox;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.IInventory;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Storage ESP for every item-storage block of 1.12.2: chests (single, double, trapped), ender chests, hoppers,
 * dispensers, droppers, furnaces, brewing stands and shulker boxes. Each type has its own switch, color and
 * range. Blocks are found through the loaded tile entities and drawn through walls with their real shape; a
 * double chest is detected like vanilla does (same block, same facing, side by side) and drawn as one box.
 */
public class ChestEsp extends Module {
    /** The three settings every storage type has. */
    private static final class Kind {
        final BoolSetting on;
        final ColorSetting color;
        final NumberSetting range;

        Kind(BoolSetting on, ColorSetting color, NumberSetting range) {
            this.on = on;
            this.color = color;
            this.range = range;
        }
    }

    private final Kind chests = kind("Chests", 0.08f, 0.9f, 64);
    private final Kind doubles = kind("Double chests", 0.14f, 0.9f, 64);
    private final Kind trapped = kind("Trapped chests", 0.0f, 0.85f, 64);
    private final Kind ender = kind("Ender chests", 0.78f, 0.8f, 64);
    private final Kind shulkers = kind("Shulker boxes", 0.88f, 0.7f, 64);
    private final Kind hoppers = kind("Hoppers", 0.5f, 0.6f, 32);
    private final Kind dispensers = kind("Dispensers", 0.6f, 0.7f, 32);
    private final Kind droppers = kind("Droppers", 0.66f, 0.4f, 32);
    private final Kind furnaces = kind("Furnaces", 0.07f, 0.5f, 32);
    private final Kind brewing = kind("Brewing stands", 0.33f, 0.7f, 32);
    private final BoolSetting names = add(new BoolSetting("Show Names", true));
    private final BoolSetting distance = add(new BoolSetting("Show Distance", false));
    private final NumberSetting lineWidth = add(new NumberSetting("Line width", 1.5, 1, 4, 0.5));
    private final NumberSetting fill = add(new NumberSetting("Fill alpha", 40, 0, 120, 5));
    private final NumberSetting textSize = add(new NumberSetting("Text size", 1.0, 0.5, 2.0, 0.1));

    private static final class Entry {
        final AxisAlignedBB bb;
        final int rgb;
        final String name;
        final double dist;

        Entry(AxisAlignedBB bb, int rgb, String name, double dist) {
            this.bb = bb;
            this.rgb = rgb;
            this.name = name;
            this.dist = dist;
        }
    }

    public ChestEsp() {
        super("Chest ESP", Category.RENDER);
    }

    private Kind kind(String label, float hue, float sat, double range) {
        return new Kind(add(new BoolSetting(label, true)), add(new ColorSetting(label + " color", hue, sat)),
                add(new NumberSetting(label + " range", range, 8, 128, 4)));
    }

    private Kind classify(Block block, boolean dbl) {
        if (block == Blocks.CHEST) return dbl ? doubles : chests;
        if (block == Blocks.TRAPPED_CHEST) return trapped;
        if (block == Blocks.ENDER_CHEST) return ender;
        if (block == Blocks.HOPPER) return hoppers;
        if (block == Blocks.DISPENSER) return dispensers;
        if (block == Blocks.DROPPER) return droppers;
        if (block == Blocks.FURNACE || block == Blocks.LIT_FURNACE) return furnaces;
        if (block == Blocks.BREWING_STAND) return brewing;
        if (block instanceof BlockShulkerBox) return shulkers;
        return null;
    }

    @Override
    public void onRender3D(float pt) {
        List<Entry> found = new ArrayList<>();
        for (TileEntity te : mc.world.loadedTileEntityList) {
            if (te.isInvalid() || !(te instanceof IInventory || te instanceof TileEntityEnderChest)) continue;
            BlockPos pos = te.getPos();
            IBlockState state = mc.world.getBlockState(pos);
            Block block = state.getBlock();
            BlockPos partner = block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST ? partner(state, pos) : null;
            boolean dbl = partner != null;
            Kind kind = classify(block, dbl);
            if (kind == null || !kind.on.get()) continue;
            double d = mc.player.getDistanceSq(pos);
            double r = kind.range.get();
            if (d > r * r) continue;
            if (dbl && pos.compareTo(partner) > 0) continue; // a double chest is drawn once, from its first half
            AxisAlignedBB bb = shape(state, pos);
            if (dbl) bb = bb.union(shape(mc.world.getBlockState(partner), partner));
            String name = dbl && block == Blocks.CHEST ? I18n.format("container.chestDouble")
                    : block.getLocalizedName() + (dbl ? " x2" : "");
            found.add(new Entry(bb, kind.color.getRGB(), name, Math.sqrt(d)));
        }
        if (found.isEmpty()) return;

        RenderUtil.begin3D(pt, lineWidth.getFloat());
        int fa = fill.getInt();
        if (fa > 0) {
            RenderUtil.beginQuads();
            for (Entry e : found) RenderUtil.quadBox(e.bb, e.rgb, fa);
            RenderUtil.endBatch();
        }
        RenderUtil.beginLines();
        for (Entry e : found) RenderUtil.lineBox(e.bb, e.rgb, 255);
        RenderUtil.endBatch();
        RenderUtil.end3D();

        if (!names.get() && !distance.get()) return;
        RenderUtil.beginText3D(pt);
        for (Entry e : found) {
            List<String> lines = new ArrayList<>();
            if (names.get()) lines.add("\u00a7f" + e.name);
            if (distance.get()) lines.add("\u00a77" + String.format(Locale.ROOT, "%.1fm", e.dist));
            RenderUtil.drawTag((e.bb.minX + e.bb.maxX) / 2.0, e.bb.maxY + 0.2, (e.bb.minZ + e.bb.maxZ) / 2.0,
                    lines.toArray(new String[0]), 0xFFFFFFFF, textSize.getFloat());
        }
        RenderUtil.end3D();
    }

    /** Real block shape in world coordinates. */
    private AxisAlignedBB shape(IBlockState state, BlockPos pos) {
        return state.getBoundingBox(mc.world, pos).offset(pos);
    }

    /** Other half of a double chest: same block and facing, next to this one along the side axis. */
    private BlockPos partner(IBlockState state, BlockPos pos) {
        EnumFacing f = state.getValue(BlockChest.FACING);
        BlockPos[] candidates = {pos.offset(f.rotateY()), pos.offset(f.rotateYCCW())};
        for (BlockPos n : candidates) {
            IBlockState ns = mc.world.getBlockState(n);
            if (ns.getBlock() == state.getBlock() && ns.getValue(BlockChest.FACING) == f) return n;
        }
        return null;
    }
}
