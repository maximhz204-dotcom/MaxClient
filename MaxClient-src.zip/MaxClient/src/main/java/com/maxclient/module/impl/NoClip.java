package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;

/** Singleplayer-only no-clip, using the same noClip flag vanilla's own spectator mode sets on the entity. */
public class NoClip extends Module {
    public NoClip() {
        super("NoClip", Category.MOVEMENT);
    }

    @Override
    protected void onEnable() {
        if (!mc.isIntegratedServerRunning()) {
            setEnabled(false);
            return;
        }
        mc.player.noClip = true;
    }

    @Override
    protected void onDisable() {
        if (mc.player != null) mc.player.noClip = false;
    }

    @Override
    public void onTick() {
        if (!mc.isIntegratedServerRunning()) setEnabled(false);
    }
}
