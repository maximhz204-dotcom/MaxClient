package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;

/** Singleplayer-only no-clip, using the same noClip flag vanilla's own spectator mode sets on the entity. */
public class NoClip extends Module {
    public NoClip() {
        super("Ноклип", Category.MOVEMENT);
    }
    /** Singleplayer, or real server-granted Creative mode - a flag the server pushes, not one the client can fake.
     *  This is exactly the "singleplayer or an authorized testing environment" rule this project was given. */
    private boolean authorized() {
        return mc.isIntegratedServerRunning() || (mc.player != null && mc.player.capabilities.isCreativeMode);
    }


    @Override
    protected void onEnable() {
        if (!authorized()) {
            setEnabled(false);
            return;
        }
        mc.player.noClip = true;
    }

    @Override
    protected void onDisable() {
        if (mc.player != null) mc.player.noClip = false;
    }

    @Override
    public void onTick() {
        if (!authorized()) setEnabled(false);
    }
}
