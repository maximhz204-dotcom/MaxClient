package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.ColorSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

/** Draws a small colored indicator over the crosshair while it is actually on a living entity. */
public class HitColor extends Module {
    private final ColorSetting color = add(new ColorSetting("Color", 0.0f, 0.9f));

    public HitColor() {
        super("ЦветПрицела", Category.COMBAT);
        enabledByDefault();
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        if (mc.pointedEntity == null) return;
        int cx = sr.getScaledWidth() / 2, cy = sr.getScaledHeight() / 2;
        int c = 0xFF000000 | color.getRGB();
        GlStateManager.enableBlend();
        Gui.drawRect(cx - 4, cy - 1, cx + 4, cy + 1, c);
        Gui.drawRect(cx - 1, cy - 4, cx + 1, cy + 4, c);
    }
}
