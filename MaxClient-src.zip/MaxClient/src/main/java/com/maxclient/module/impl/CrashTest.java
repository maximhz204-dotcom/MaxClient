package com.maxclient.module.impl;

import com.maxclient.crashtest.CrashTestClientData;
import com.maxclient.crashtest.CrashTestNetwork;
import com.maxclient.crashtest.MetricsPacket;
import com.maxclient.crashtest.StartTestPacket;
import com.maxclient.gui.Theme;
import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;

import java.util.Locale;

/**
 * Local HUD diagnostics panel built only from real client data - nothing invented, nothing sent:
 * - Ping / Response: NetworkPlayerInfo.getResponseTime(), the one round-trip value vanilla already keeps from
 *   its own keep-alive traffic (shown in the tab list). Minecraft exposes no second, independent timer.
 * - Spikes / Disconnects: counted from that same real ping and from real connection-state changes - a spike is
 *   a reading far above the recent real average, a disconnect is mc.getConnection() actually becoming null.
 * - Ping graph: bar chart of the last 40 REAL readings above, nothing synthetic.
 * - TPS: only measurable for a real server. Multiplayer has no public tick-rate API without extra packets, so
 *   it is computed only in singleplayer from real elapsed time between actual client ticks (lockstep with the
 *   integrated server); multiplayer always shows N/A.
 * - Packets: Minecraft's public API exposes no packet counters, so this honestly shows N/A rather than guess
 *   an undocumented field (guessing obscure members has broken this project's build before).
 * Start/Stop (the "Running" setting) only pauses recording; it never touches the module's enabled state.
 * Nothing here, and nothing else in the project, disables the module except the user's toggle or Auto Stop -
 * verified against ModuleManager/ClickGui - so it survives disconnects, world changes and reconnects.
 */
public class CrashTest extends Module {
    private enum State { IDLE, RUNNING, STOPPED, FINISHED }

    private static final int HISTORY = 40;

    private final BoolSetting running = add(new BoolSetting("Running", true));
    private final NumberSetting intensity = add(new NumberSetting("Intensity", 50, 1, 100, 1));
    private final NumberSetting duration = add(new NumberSetting("Duration (s)", 10, 1, 60, 1));
    private final NumberSetting posX = add(new NumberSetting("X", 6, 0, 600, 1));
    private final NumberSetting posY = add(new NumberSetting("Y", 30, 0, 400, 1));
    private final BoolSetting autoStop = add(new BoolSetting("Auto stop", true));

    private State state = State.IDLE;
    private long startedAt, finishedAt;
    private long samples, spikes, disconnects;
    private int ping = -1;
    private float pingAvg = -1f;
    private float tps = -1f;
    private boolean connected, wasConnected;

    private final int[] history = new int[HISTORY];
    private int historyCount;

    private int refreshTicks;
    private long lastTickMs = -1;
    private float tickAvgMs = 50f;

    public CrashTest() {
        super("Crash Test", Category.HUD);
    }

    @Override
    protected void onEnable() {
        state = State.RUNNING;
        startedAt = System.currentTimeMillis();
        samples = spikes = disconnects = 0;
        refreshTicks = 0;
        historyCount = 0;
        lastTickMs = -1;
        ping = -1;
        pingAvg = -1f;
        tps = -1f;
        connected = wasConnected = false;
        CrashTestClientData.clear();
        sendStart(true);
    }

    /** Only reached from the user toggling the module off, or Auto Stop below - never from world/network events. */
    @Override
    protected void onDisable() {
        if (state == State.RUNNING || state == State.STOPPED) state = State.IDLE;
        sendStart(false);
    }

    /** Tells the server-side component (if installed on the server) to start/stop sending real metrics. */
    private void sendStart(boolean start) {
        if (mc.getConnection() == null) return;
        int interval = Math.max(5, Math.round(20 * (1.5f - intensity.getFloat() / 100f)));
        CrashTestNetwork.CHANNEL.sendToServer(new StartTestPacket(start, interval, duration.getInt()));
    }

    @Override
    public void onTick() {
        if (state == State.IDLE) return;
        connected = mc.player != null && mc.getConnection() != null;
        if (wasConnected && !connected) disconnects++;
        wasConnected = connected;

        if (!running.get()) {
            if (state == State.RUNNING) state = State.STOPPED;
            return;
        }
        if (state == State.STOPPED) state = State.RUNNING;
        if (state != State.RUNNING) return;

        long now = System.currentTimeMillis();
        if (lastTickMs > 0) tickAvgMs += ((now - lastTickMs) - tickAvgMs) * 0.1f;
        lastTickMs = now;

        tps = connected && mc.isIntegratedServerRunning() ? Math.max(0f, Math.min(20f, 1000f / Math.max(1f, tickAvgMs))) : -1f;

        int interval = Math.max(1, 20 - Math.round(intensity.getFloat() / 5f));
        if (refreshTicks++ % interval == 0 && connected) {
            NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUniqueID());
            if (info != null) {
                ping = Math.max(0, info.getResponseTime());
                samples++;
                if (pingAvg < 0) pingAvg = ping; else pingAvg += (ping - pingAvg) * 0.2f;
                if (pingAvg > 0 && ping > pingAvg * 2f && ping > 50) spikes++;
                if (historyCount < HISTORY) {
                    history[historyCount++] = ping;
                } else {
                    System.arraycopy(history, 1, history, 0, HISTORY - 1);
                    history[HISTORY - 1] = ping;
                }
            }
        }

        if (now - startedAt >= duration.get() * 1000L) {
            state = State.FINISHED;
            finishedAt = now;
            sendStart(false);
            if (autoStop.get()) setEnabled(false);
        }
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        FontRenderer fr = mc.fontRenderer;
        MetricsPacket srv = CrashTestClientData.latest(5000);
        int x = posX.getInt(), y = posY.getInt(), w = 160, graphH = 24, h = 108 + graphH + (srv != null ? 30 : 10);

        GlStateManager.enableBlend();
        Gui.drawRect(x, y, x + w, y + h, 0xC0120019);
        RenderUtil.hGradient(x, y, x + w, y + 14, Theme.ACCENT_DARK, Theme.ACCENT);
        Gui.drawRect(x, y, x + 2, y + h, Theme.ACCENT);
        Gui.drawRect(x + w - 2, y, x + w, y + h, Theme.ACCENT);
        Gui.drawRect(x, y + h - 2, x + w, y + h, Theme.ACCENT);
        fr.drawString("CRASH TEST", x + 4, y + 3, 0xFFEEE6FF, true);

        String stateText = state.name();
        int stateColor = state == State.RUNNING ? 0xFF55FF88 : state == State.STOPPED ? 0xFFFFD24C
                : state == State.FINISHED ? 0xFFFFD24C : 0xFF8F86A8;
        fr.drawString("Status: " + stateText, x + 4, y + 16, stateColor, true);

        boolean live = connected && ping >= 0;
        fr.drawString(live ? "LIVE DATA" : "UNAVAILABLE", x + 4, y + 27, live ? 0xFF55FF88 : 0xFFFF5555, true);
        fr.drawString(live ? "Ping/Response: " + ping + " ms" : "Ping/Response: --", x + 4, y + 37, 0xFFEEE6FF, true);
        fr.drawString(tps >= 0 ? String.format(Locale.ROOT, "TPS: %.1f", tps) : "TPS: N/A", x + 4, y + 47, 0xFFEEE6FF, true);
        fr.drawString("Packets: N/A", x + 4, y + 57, 0xFF8F86A8, true);
        fr.drawString("Samples: " + samples + "  Spikes: " + spikes, x + 4, y + 67, 0xFFC9A6FF, true);
        fr.drawString("Disconnects: " + disconnects, x + 4, y + 77, 0xFFC9A6FF, true);

        int sy = y + 87;
        if (srv != null) {
            fr.drawString(String.format(Locale.ROOT, "Server TPS: %.1f  MSPT: %.0fms", srv.tps, srv.msptMs),
                    x + 4, sy, 0xFF55FFAA, true);
            fr.drawString(String.format(Locale.ROOT, "RAM: %d/%dMB  Load: %.2f", srv.usedMb, srv.maxMb, srv.sysLoad),
                    x + 4, sy + 10, 0xFF55FFAA, true);
            sy += 20;
        } else {
            fr.drawString("Server component: N/A", x + 4, sy, 0xFF8F86A8, true);
            sy += 10;
        }

        int gx = x + 4, gy = sy, gw = w - 8;
        Gui.drawRect(gx, gy, gx + gw, gy + graphH, 0xFF1A0E26);
        if (historyCount > 1) {
            int maxVal = 20;
            for (int i = 0; i < historyCount; i++) maxVal = Math.max(maxVal, history[i]);
            int bw = Math.max(1, gw / HISTORY);
            for (int i = 0; i < historyCount; i++) {
                int bh = Math.min(graphH, Math.round(history[i] * (float) graphH / maxVal));
                int bx = gx + i * bw;
                int c = history[i] > 150 ? 0xFFFF5555 : history[i] > 80 ? 0xFFFFD24C : 0xFF55FF88;
                Gui.drawRect(bx, gy + graphH - bh, bx + Math.max(1, bw - 1), gy + graphH, c);
            }
        }

        long elapsed = state == State.IDLE ? 0 : (state == State.FINISHED ? finishedAt : System.currentTimeMillis()) - startedAt;
        float ratio = Math.max(0f, Math.min(1f, (float) (elapsed / (duration.get() * 1000.0))));
        Gui.drawRect(x + 2, y + h - 2, x + w - 2, y + h, 0xFF2A2338);
        Gui.drawRect(x + 2, y + h - 2, x + 2 + Math.round((w - 4) * ratio), y + h, Theme.ACCENT);
    }
}
