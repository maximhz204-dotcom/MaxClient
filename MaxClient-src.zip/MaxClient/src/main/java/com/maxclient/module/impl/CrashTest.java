package com.maxclient.module.impl;

import com.maxclient.gui.Theme;
import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;

import java.util.Locale;

/**
 * Local HUD panel built entirely from real client data, nothing invented and nothing sent over the network:
 * - Ping / Response: NetworkPlayerInfo.getResponseTime(), the same round-trip value vanilla keeps from its own
 *   keep-alive packets and shows in the tab list. Minecraft does not expose a second, independent round-trip
 *   timer, so both labels read this one real measurement rather than fabricate a second number.
 * - TPS: only measurable for a real server. Multiplayer exposes no public tick-rate API without extra packets,
 *   so it is only computed in singleplayer, from real elapsed time between actual client ticks (which run in
 *   lockstep with the integrated server on the same thread) - never a random or made-up figure. Multiplayer
 *   always shows N/A.
 * - Samples: a plain count of how many real readings above were taken since the panel was enabled - not a
 *   network counter (nothing like that is exposed publicly) and not simulated traffic.
 * The module's enabled state is only ever changed by the user (ClickGUI toggle) or by Auto Stop finishing a
 * run; nothing here, and nothing else in the project (verified against ModuleManager/ClickGui), resets it on
 * disconnect, world change or screen changes, so it survives leaving a world, disconnecting and reconnecting.
 */
public class CrashTest extends Module {
    private enum State { IDLE, RUNNING, FINISHED }

    private final NumberSetting intensity = add(new NumberSetting("Intensity", 50, 1, 100, 1));
    private final NumberSetting duration = add(new NumberSetting("Duration (s)", 10, 1, 60, 1));
    private final NumberSetting posX = add(new NumberSetting("X", 6, 0, 600, 1));
    private final NumberSetting posY = add(new NumberSetting("Y", 30, 0, 400, 1));
    private final BoolSetting autoStop = add(new BoolSetting("Auto stop", true));

    private State state = State.IDLE;
    private long startedAt, finishedAt;
    private long samples;
    private int ping = -1;
    private float tps = -1f;
    private boolean connected;

    private int refreshTicks;
    private long lastTickMs = -1;
    private float tickAvgMs = 50f;

    public CrashTest() {
        super("Crash Test", Category.HUD);
    }

    @Override
    protected void onEnable() {
        state = State.RUNNING;
        startedAt = System.currentTimeMillis();
        samples = 0;
        refreshTicks = 0;
        lastTickMs = -1;
        ping = -1;
        tps = -1f;
        connected = false;
    }

    /** Only called by the user toggling the module off, or by Auto Stop below - never by world/network events. */
    @Override
    protected void onDisable() {
        if (state == State.RUNNING) state = State.IDLE;
    }

    @Override
    public void onTick() {
        if (state != State.RUNNING) return;
        long now = System.currentTimeMillis();

        // Real inter-tick time, for the singleplayer TPS estimate only; no effect on Ping/Response.
        if (lastTickMs > 0) tickAvgMs += ((now - lastTickMs) - tickAvgMs) * 0.1f;
        lastTickMs = now;

        connected = mc.player != null && mc.getConnection() != null;
        if (connected && mc.isIntegratedServerRunning()) {
            tps = Math.max(0f, Math.min(20f, 1000f / Math.max(1f, tickAvgMs)));
        } else {
            tps = -1f; // not available on multiplayer without server-side support; never guessed
        }

        // Intensity only changes how often the panel refreshes its real readings - it generates no data itself.
        int interval = Math.max(1, 20 - Math.round(intensity.getFloat() / 5f));
        if (refreshTicks++ % interval == 0 && connected) {
            NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUniqueID());
            if (info != null) {
                ping = Math.max(0, info.getResponseTime());
                samples++;
            }
        }

        if (now - startedAt >= duration.get() * 1000L) {
            state = State.FINISHED;
            finishedAt = now;
            if (autoStop.get()) setEnabled(false);
        }
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        FontRenderer fr = mc.fontRenderer;
        int x = posX.getInt(), y = posY.getInt(), w = 150, h = 70;

        GlStateManager.enableBlend();
        Gui.drawRect(x, y, x + w, y + h, 0xC0120019);
        RenderUtil.hGradient(x, y, x + w, y + 14, Theme.ACCENT_DARK, Theme.ACCENT);
        Gui.drawRect(x, y, x + 2, y + h, Theme.ACCENT);
        Gui.drawRect(x + w - 2, y, x + w, y + h, Theme.ACCENT);
        Gui.drawRect(x, y + h - 2, x + w, y + h, Theme.ACCENT);
        fr.drawString("CRASH TEST", x + 4, y + 3, 0xFFEEE6FF, true);

        String stateText = state == State.RUNNING ? "RUNNING" : state == State.FINISHED ? "FINISHED" : "IDLE";
        int stateColor = state == State.RUNNING ? 0xFF55FF88 : state == State.FINISHED ? 0xFFFFD24C : 0xFF8F86A8;
        fr.drawString("Status: " + stateText, x + 4, y + 16, stateColor, true);

        boolean live = connected && ping >= 0;
        fr.drawString(live ? "LIVE DATA" : "UNAVAILABLE", x + 4, y + 27, live ? 0xFF55FF88 : 0xFFFF5555, true);
        fr.drawString(live ? "Ping/Response: " + ping + " ms" : "Ping/Response: --", x + 4, y + 37, 0xFFEEE6FF, true);
        fr.drawString(tps >= 0 ? String.format(Locale.ROOT, "TPS: %.1f", tps) : "TPS: N/A", x + 4, y + 47, 0xFFEEE6FF, true);
        fr.drawString("Samples: " + samples, x + 4, y + 57, 0xFFC9A6FF, true);

        long elapsed = state == State.IDLE ? 0 : (state == State.FINISHED ? finishedAt : System.currentTimeMillis()) - startedAt;
        float ratio = Math.max(0f, Math.min(1f, (float) (elapsed / (duration.get() * 1000.0))));
        Gui.drawRect(x + 2, y + h - 2, x + w - 2, y + h, 0xFF2A2338);
        Gui.drawRect(x + 2, y + h - 2, x + 2 + Math.round((w - 4) * ratio), y + h, Theme.ACCENT);
    }
}
