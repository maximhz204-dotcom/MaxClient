package com.maxclient.module.impl;

import com.maxclient.gui.Theme;
import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

import java.util.Locale;
import java.util.Random;

/**
 * Local-only HUD simulation panel. Nothing here sends a packet, opens a connection or touches the network in
 * any way: "Virtual requests", "Ping" and "Response" are randomized numbers generated on the client for show.
 * It only reads the real server ping the game already has (NetworkPlayerInfo) as the baseline those numbers
 * jitter around, so the panel looks plausible without faking a real measurement as a claim.
 */
public class CrashTest extends Module {
    private enum State { IDLE, RUNNING, FINISHED }

    private final NumberSetting intensity = add(new NumberSetting("Intensity", 50, 1, 100, 1));
    private final NumberSetting duration = add(new NumberSetting("Duration (s)", 10, 1, 60, 1));
    private final NumberSetting posX = add(new NumberSetting("X", 6, 0, 600, 1));
    private final NumberSetting posY = add(new NumberSetting("Y", 30, 0, 400, 1));
    private final BoolSetting autoStop = add(new BoolSetting("Auto stop", true));

    private final Random rng = new Random();
    private State state = State.IDLE;
    private long startedAt, finishedAt;
    private long requests;
    private float pingShown, responseShown;
    private float tpsShown = 20f;
    private long lastTick;

    public CrashTest() {
        super("Crash Test", Category.HUD);
    }

    @Override
    protected void onEnable() {
        state = State.RUNNING;
        startedAt = System.currentTimeMillis();
        requests = 0;
        lastTick = startedAt;
        pingShown = realPing();
        responseShown = pingShown;
        tpsShown = 20f;
    }

    @Override
    protected void onDisable() {
        if (state == State.RUNNING) state = State.IDLE;
    }

    private int realPing() {
        if (mc.player == null || mc.getConnection() == null) return 40;
        net.minecraft.client.network.NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUniqueID());
        return info != null ? Math.max(1, info.getResponseTime()) : 40;
    }

    @Override
    public void onTick() {
        if (state != State.RUNNING) return;
        long now = System.currentTimeMillis();
        long elapsed = now - startedAt;
        float dt = (now - lastTick) / 1000f;
        lastTick = now;

        // Simulated load: how many "virtual requests" per second the chosen intensity produces, purely local.
        float perSecond = 5f + intensity.getFloat() * 2.5f;
        requests += Math.round(perSecond * dt);

        float base = realPing();
        float strain = intensity.getFloat() / 100f;
        pingShown = base + base * strain * (0.5f + rng.nextFloat());
        responseShown = pingShown * (0.8f + rng.nextFloat() * 0.6f);
        tpsShown = Math.max(1f, 20f - strain * (6f + rng.nextFloat() * 6f));

        if (elapsed >= duration.get() * 1000L) {
            state = State.FINISHED;
            finishedAt = now;
            if (autoStop.get()) setEnabled(false);
        }
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        FontRenderer fr = mc.fontRenderer;
        int x = posX.getInt(), y = posY.getInt(), w = 150;
        String title = "CRASH TEST (SIMULATION)";
        int h = 70;

        GlStateManager.enableBlend();
        Gui.drawRect(x, y, x + w, y + h, 0xC0120019);
        RenderUtil.hGradient(x, y, x + w, y + 14, Theme.ACCENT_DARK, Theme.ACCENT);
        Gui.drawRect(x, y, x + 2, y + h, Theme.ACCENT);
        Gui.drawRect(x + w - 2, y, x + w, y + h, Theme.ACCENT);
        Gui.drawRect(x, y + h - 2, x + w, y + h, Theme.ACCENT);
        fr.drawString(title, x + 4, y + 3, 0xFFEEE6FF, true);

        String stateText = state == State.RUNNING ? "RUNNING" : state == State.FINISHED ? "FINISHED" : "IDLE";
        int stateColor = state == State.RUNNING ? 0xFF55FF88 : state == State.FINISHED ? 0xFFFFD24C : 0xFF8F86A8;
        fr.drawString("Status: " + stateText, x + 4, y + 16, stateColor, true);
        fr.drawString(String.format(Locale.ROOT, "Ping: %.0f ms", pingShown), x + 4, y + 27, 0xFFEEE6FF, true);
        fr.drawString(String.format(Locale.ROOT, "Response: %.0f ms", responseShown), x + 4, y + 37, 0xFFEEE6FF, true);
        fr.drawString(String.format(Locale.ROOT, "TPS (sim): %.1f", tpsShown), x + 4, y + 47, 0xFFEEE6FF, true);
        fr.drawString("Requests: " + requests, x + 4, y + 57, 0xFFC9A6FF, true);

        long elapsed = state == State.IDLE ? 0 : (state == State.FINISHED ? finishedAt : System.currentTimeMillis()) - startedAt;
        float ratio = Math.max(0f, Math.min(1f, (float) (elapsed / (duration.get() * 1000.0))));
        int barY = y + h - 1;
        Gui.drawRect(x, barY, x + w, barY + 0, 0); // no-op kept for clarity of layout; real bar below
        Gui.drawRect(x + 2, y + h - 2 - 0, x + w - 2, y + h - 2, 0xFF2A2338);
        Gui.drawRect(x + 2, y + h - 2 - 0, x + 2 + Math.round((w - 4) * ratio), y + h - 2, Theme.ACCENT);
    }
}
