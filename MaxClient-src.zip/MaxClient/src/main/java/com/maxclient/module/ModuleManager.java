package com.maxclient.module;

import com.maxclient.module.impl.*;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final Map<Category, List<Module>> BY_CATEGORY = new EnumMap<>(Category.class);

    private ModuleManager() {}

    public static void init() {
        for (Category c : Category.values()) BY_CATEGORY.put(c, new ArrayList<Module>());
        register(new Hitboxes());
        register(new TriggerBot());
        register(new XRay());
        register(new Fullbright());
        register(new Sprint());
        register(new NoFall());
        register(new FpsHud());
        register(new CoordsHud());
        register(new ModuleList());
        MinecraftForge.EVENT_BUS.register(new ModuleManager());
    }

    private static void register(Module m) {
        MODULES.add(m);
        BY_CATEGORY.get(m.category).add(m);
    }

    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }

    public static List<Module> in(Category c) { return Collections.unmodifiableList(BY_CATEGORY.get(c)); }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (e.phase != TickEvent.Phase.END || mc.player == null || mc.world == null) return;
        for (Module m : MODULES) if (m.isEnabled()) m.onTick();
    }

    @SubscribeEvent
    public void onWorld(RenderWorldLastEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null) return;
        for (Module m : MODULES) if (m.isEnabled()) m.onRender3D(e.getPartialTicks());
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL || mc.player == null
                || mc.gameSettings.showDebugInfo) return;
        for (Module m : MODULES) if (m.isEnabled()) m.onRender2D(e.getResolution());
    }
}
