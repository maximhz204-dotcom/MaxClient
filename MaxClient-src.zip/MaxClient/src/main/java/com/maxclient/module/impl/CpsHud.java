package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.NumberSetting;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.input.Mouse;

import java.util.ArrayDeque;
import java.util.Deque;

/** Counts real left/right mouse-button press events over the last second - no simulated clicks. */
public class CpsHud extends Module {
    private final NumberSetting posX = add(new NumberSetting("X", 6, 0, 600, 1));
    private final NumberSetting posY = add(new NumberSetting("Y", 210, 0, 400, 1));
    private final Deque<Long> left = new ArrayDeque<>(), right = new ArrayDeque<>();

    public CpsHud() {
        super("CPS Counter", Category.HUD);
        enabledByDefault();
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onMouse(InputEvent.MouseInputEvent e) {
        int btn = Mouse.getEventButton();
        if (!Mouse.getEventButtonState()) return;
        if (btn == 0) left.addLast(System.currentTimeMillis());
        else if (btn == 1) right.addLast(System.currentTimeMillis());
    }

    private int countRecent(Deque<Long> q) {
        long cutoff = System.currentTimeMillis() - 1000;
        while (!q.isEmpty() && q.peekFirst() < cutoff) q.pollFirst();
        return q.size();
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        String text = "CPS: " + countRecent(left) + " / " + countRecent(right);
        mc.fontRenderer.drawString(text, posX.getFloat(), posY.getFloat(), 0xFFEEE6FF, true);
    }
}
