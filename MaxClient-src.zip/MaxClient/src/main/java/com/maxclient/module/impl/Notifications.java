package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

import java.util.ArrayList;
import java.util.List;

/** Small toasts in the top-right corner when any other module is turned on/off. Fed by Module.setEnabled. */
public class Notifications extends Module {
    private static final long LIFETIME_MS = 2000, FADE_MS = 400;
    private static final List<Toast> QUEUE = new ArrayList<>();
    private static volatile boolean active;

    private static final class Toast {
        final String text;
        final int color;
        final long at = System.currentTimeMillis();

        Toast(String text, int color) {
            this.text = text;
            this.color = color;
        }
    }

    public Notifications() {
        super("Notifications", Category.HUD);
        enabledByDefault();
        active = true;
    }

    /** Called by Module.setEnabled for every other module; a no-op while this module is off. */
    public static void push(String name, boolean on) {
        if (!active) return;
        synchronized (QUEUE) {
            QUEUE.add(new Toast(name + (on ? " enabled" : " disabled"), on ? 0xFF55FF88 : 0xFFFF5555));
            if (QUEUE.size() > 6) QUEUE.remove(0);
        }
    }

    @Override
    protected void onEnable() { active = true; }

    @Override
    protected void onDisable() {
        active = false;
        synchronized (QUEUE) { QUEUE.clear(); }
    }

    @Override
    public void onRender2D(ScaledResolution sr) {
        long now = System.currentTimeMillis();
        FontRenderer fr = mc.fontRenderer;
        GlStateManager.enableBlend();
        int y = 2;
        synchronized (QUEUE) {
            QUEUE.removeIf(t -> now - t.at > LIFETIME_MS);
            for (Toast t : QUEUE) {
                long age = now - t.at;
                float a = age > LIFETIME_MS - FADE_MS ? Math.max(0f, (LIFETIME_MS - age) / (float) FADE_MS) : 1f;
                int bg = (Math.round(160 * a) << 24);
                int w = fr.getStringWidth(t.text) + 8;
                int x = sr.getScaledWidth() - w - 4;
                Gui.drawRect(x, y, x + w, y + 12, bg);
                Gui.drawRect(x, y, x + 2, y + 12, (Math.round(255 * a) << 24) | (t.color & 0xFFFFFF));
                fr.drawString(t.text, x + 5, y + 2, (Math.round(220 * a) << 24) | 0xFFFFFF, false);
                y += 14;
            }
        }
    }
}
