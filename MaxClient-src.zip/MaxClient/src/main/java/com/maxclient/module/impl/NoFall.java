package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.NumberSetting;
import net.minecraft.network.play.client.CPacketPlayer;

public class NoFall extends Module {
    private final NumberSetting distance = add(new NumberSetting("Min distance", 3, 2, 10, 0.5));

    public NoFall() {
        super("NoFall", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.player.fallDistance > distance.getFloat() && !mc.player.capabilities.isFlying
                && !mc.player.isElytraFlying() && mc.getConnection() != null) {
            mc.getConnection().sendPacket(new CPacketPlayer(true));
        }
    }
}
