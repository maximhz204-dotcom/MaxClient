package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.NumberSetting;

/**
 * Singleplayer-only flight. A dedicated server (or any remote server) cannot be trusted to accept client-set
 * motion, so this never engages outside the integrated server - exactly the "singleplayer only" requirement.
 */
public class Fly extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.6, 0.1, 2.0, 0.1));

    public Fly() {
        super("Fly", Category.MOVEMENT);
    }

    @Override
    protected void onDisable() {
        if (mc.player != null) mc.player.capabilities.isFlying = false;
    }

    @Override
    public void onTick() {
        if (!mc.isIntegratedServerRunning()) {
            setEnabled(false);
            return;
        }
        mc.player.capabilities.isFlying = true;
        mc.player.fallDistance = 0f;
        float f = speed.getFloat();
        if (mc.gameSettings.keyBindJump.isKeyDown()) mc.player.motionY = f;
        else if (mc.gameSettings.keyBindSneak.isKeyDown()) mc.player.motionY = -f;
        else mc.player.motionY = 0;
    }
}
