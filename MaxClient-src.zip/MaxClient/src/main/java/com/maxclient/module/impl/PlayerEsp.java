package com.maxclient.module.impl;

import com.maxclient.friend.FriendManager;
import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.ModeSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;

import com.maxclient.module.ModuleManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Player ESP: 3D box around other players (filled "Box", wireframe "Outline" or "Both"), drawn through walls,
 * plus a name / distance / health tag above the head. Pure world-space drawing in RenderWorldLastEvent;
 * all GL state is saved and restored by RenderUtil.
 */
public class PlayerEsp extends Module {
    private final ModeSetting mode = add(new ModeSetting("ESP Mode", 2, "Box", "Outline", "Both"));
    private final BoolSetting names = add(new BoolSetting("Show Names", true));
    private final BoolSetting distance = add(new BoolSetting("Show Distance", true));
    private final BoolSetting health = add(new BoolSetting("Show Health", true));
    private final ColorSetting color = add(new ColorSetting("ESP Color", 0.76f, 0.85f));
    private final ColorSetting friendColor = add(new ColorSetting("Friend color", 0.33f, 0.8f));
    private final NumberSetting maxDistance = add(new NumberSetting("Maximum Distance", 100, 10, 256, 5));
    private final BoolSetting ignoreFriends = add(new BoolSetting("Ignore Friends", false));
    private final BoolSetting ignoreInvisible = add(new BoolSetting("Ignore Invisible", false));
    private final NumberSetting lineWidth = add(new NumberSetting("Line width", 1.5, 1, 4, 0.5));
    private final NumberSetting fill = add(new NumberSetting("Fill alpha", 40, 0, 120, 5));
    private final NumberSetting textSize = add(new NumberSetting("Text size", 1.0, 0.5, 2.0, 0.1));

    /** Players found by the last render pass; Nametag reuses this list instead of searching on its own. */
    private List<EntityPlayer> visible = new ArrayList<>();

    public PlayerEsp() {
        super("Player ESP", Category.RENDER);
    }

    @Override
    protected void onDisable() {
        visible = new ArrayList<>();
    }

    /** Players currently highlighted by this module (empty while it is off). */
    public List<EntityPlayer> players() {
        return isEnabled() ? visible : Collections.<EntityPlayer>emptyList();
    }

    /** How many text lines this module draws above a player's head. */
    public int tagLineCount() {
        return (showsName() ? 1 : 0) + (distance.get() || health.get() ? 1 : 0);
    }

    public float tagTextSize() {
        return textSize.getFloat();
    }

    /** The nick is left to Nametag while Nametag is active, so it is not drawn twice. */
    private boolean showsName() {
        Nametag n = ModuleManager.get(Nametag.class);
        return names.get() && !(n != null && n.isActive() && n.showsNicks());
    }

    private boolean accept(EntityPlayer p, float maxDist) {
        if (p == mc.player || p == mc.getRenderViewEntity() || p.isDead || mc.player.getDistance(p) > maxDist) {
            return false;
        }
        if (ignoreInvisible.get() && p.isInvisible()) return false;
        return !(ignoreFriends.get() && FriendManager.isFriend(p.getName()));
    }

    @Override
    public void onRender3D(float pt) {
        float maxDist = maxDistance.getFloat();
        List<EntityPlayer> players = new ArrayList<>();
        for (EntityPlayer p : mc.world.playerEntities) {
            if (accept(p, maxDist)) players.add(p);
        }
        visible = players;
        if (players.isEmpty()) return;

        double k = 1.0 - pt;
        int idx = mode.getIndex();
        int fillAlpha = idx == 1 ? 0 : (idx == 0 ? Math.max(fill.getInt(), 20) : fill.getInt());
        int lineAlpha = idx == 0 ? 0 : 255;

        RenderUtil.begin3D(pt, lineWidth.getFloat());
        for (EntityPlayer p : players) {
            RenderUtil.box(box(p, k), rgb(p), fillAlpha, lineAlpha);
        }
        RenderUtil.end3D();

        if (!names.get() && !distance.get() && !health.get()) return;
        RenderUtil.beginText3D(pt);
        for (EntityPlayer p : players) {
            String[] lines = tagLines(p);
            if (lines.length == 0) continue;
            AxisAlignedBB bb = box(p, k);
            RenderUtil.drawTag((bb.minX + bb.maxX) / 2.0, bb.maxY + 0.25, (bb.minZ + bb.maxZ) / 2.0, lines,
                    0xFFFFFFFF, textSize.getFloat());
        }
        RenderUtil.end3D();
    }

    private int rgb(EntityPlayer p) {
        return FriendManager.isFriend(p.getName()) ? friendColor.getRGB() : color.getRGB();
    }

    /** Player's box at the interpolated render position. */
    static AxisAlignedBB box(EntityPlayer p, double k) {
        return p.getEntityBoundingBox().offset((p.lastTickPosX - p.posX) * k, (p.lastTickPosY - p.posY) * k,
                (p.lastTickPosZ - p.posZ) * k);
    }

    private String[] tagLines(EntityPlayer p) {
        List<String> lines = new ArrayList<>();
        if (showsName()) lines.add((FriendManager.isFriend(p.getName()) ? "\u00a7a" : "\u00a7f") + p.getName());
        StringBuilder info = new StringBuilder();
        if (distance.get()) {
            info.append("\u00a77").append(String.format(Locale.ROOT, "%.1fm", mc.player.getDistance(p)));
        }
        if (health.get()) {
            float hp = p.getHealth() + p.getAbsorptionAmount();
            float ratio = hp / Math.max(1f, p.getMaxHealth());
            if (info.length() > 0) info.append(' ');
            info.append(ratio > 0.66f ? "\u00a7a" : ratio > 0.33f ? "\u00a7e" : "\u00a7c")
                    .append(String.format(Locale.ROOT, "%.1f HP", hp));
        }
        if (info.length() > 0) lines.add(info.toString());
        return lines.toArray(new String[0]);
    }
}
