package com.maxclient.module;

public enum Category {
    COMBAT("Бой"), RENDER("Рендер"), MOVEMENT("Движение"), PLAYER("Игрок"), HUD("HUD");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
