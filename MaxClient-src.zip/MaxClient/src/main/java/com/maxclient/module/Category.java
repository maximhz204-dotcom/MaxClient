package com.maxclient.module;

public enum Category {
    COMBAT("Combat"), RENDER("Render"), MOVEMENT("Movement"), PLAYER("Player"), HUD("HUD");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
