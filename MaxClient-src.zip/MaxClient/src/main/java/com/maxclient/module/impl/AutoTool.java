package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

/**
 * Silent tool switch for ANY held item (sword, block, empty hand, a different tool). While you mine, the best
 * hotbar tool (pickaxe, axe, shovel, shears...) for the block is selected on the SERVER only
 * (CPacketHeldItemChange); the client keeps your slot, so the hand, hotbar and animation do not change.
 * Mining progress on the client uses that tool's real speed (Efficiency included) via PlayerEvent.BreakSpeed.
 * The server damages the tool it has selected, so the real tool wears out, not the item in your hand. The
 * client's own durability prediction on the held item is undone so the two sides never disagree.
 * No rendering code lives here.
 */
public class AutoTool extends Module {
    /** Slot the server currently believes is selected (-1 = unknown). */
    private int serverSlot = -1;
    private int lastCur = -1;
    private Object lastPlayer;
    /** Held stack (same object) and its durability before silent mining started. */
    private ItemStack guardStack;
    private int guardDamage;

    public AutoTool() {
        super("Auto Tool", Category.PLAYER);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    protected void onDisable() {
        fixDurability();
        guardStack = null;
        restore();
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.START) update(); else fixDurability();
    }

    @SubscribeEvent
    public void onMouse(InputEvent.MouseInputEvent e) {
        if (Mouse.getEventButton() == 0 || Mouse.getEventDWheel() != 0) update();
    }

    /** Client-side mining speed of the tool that the server has selected. */
    @SubscribeEvent
    public void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        if (!isEnabled() || mc.player == null || e.getEntityPlayer() != mc.player || !mc.player.world.isRemote) return;
        IBlockState state = e.getState();
        int best = bestSlot(state);
        if (best < 0 || best != serverSlot) return;
        ItemStack held = mc.player.getHeldItemMainhand();
        ItemStack tool = mc.player.inventory.getStackInSlot(best);
        float heldBase = toolSpeed(held, state);
        if (heldBase <= 0f) return;
        float speed = e.getOriginalSpeed() / heldBase * toolSpeed(tool, state);
        // Vanilla divides progress by 30 if the held item can harvest the block, otherwise by 100.
        speed *= (canHarvest(held, state) ? 30f : 100f) / (canHarvest(tool, state) ? 30f : 100f);
        e.setNewSpeed(speed);
    }

    private void update() {
        if (mc.player == null || mc.world == null || mc.getConnection() == null) {
            serverSlot = -1;
            lastCur = -1;
            guardStack = null;
            return;
        }
        if (mc.player != lastPlayer) {
            lastPlayer = mc.player;
            serverSlot = -1;
            lastCur = -1;
            guardStack = null;
        }
        fixDurability();
        int cur = mc.player.inventory.currentItem;
        if (cur != lastCur) {
            lastCur = cur;
            serverSlot = -1;
            guardStack = null;
        }
        if (serverSlot < 0) serverSlot = cur;

        int want = cur;
        if (isEnabled() && mc.currentScreen == null && !mc.playerController.isInCreativeMode()
                && mc.gameSettings.keyBindAttack.isKeyDown() && !mc.gameSettings.keyBindUseItem.isKeyDown()
                && mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK) {
            BlockPos pos = mc.objectMouseOver.getBlockPos();
            IBlockState state = mc.world.getBlockState(pos);
            if (state.getMaterial() != Material.AIR && state.getBlockHardness(mc.world, pos) >= 0f) {
                int best = bestSlot(state);
                if (best >= 0) want = best;
            }
        }
        ItemStack held = mc.player.getHeldItemMainhand();
        if (want != cur) {
            if (guardStack != held) {
                guardStack = held;
                guardDamage = held.getItemDamage();
            }
        } else {
            guardStack = null;
        }
        if (want != serverSlot) {
            mc.getConnection().sendPacket(new CPacketHeldItemChange(want));
            serverSlot = want;
        }
    }

    /**
     * While the tool is switched on the server, the client still "uses" the held item and wears it down locally
     * (vanilla prediction). The server never touches that item, so undo the local wear on the same stack object.
     * A real server update always replaces the stack object, which drops the guard automatically.
     */
    private void fixDurability() {
        if (guardStack == null || mc.player == null) return;
        ItemStack held = mc.player.getHeldItemMainhand();
        if (held == guardStack && held.isItemStackDamageable() && held.getItemDamage() > guardDamage) {
            held.setItemDamage(guardDamage);
        }
    }

    /** Puts the server back on the slot the client actually has selected. */
    private void restore() {
        if (mc.player == null || mc.getConnection() == null) {
            serverSlot = -1;
            return;
        }
        int cur = mc.player.inventory.currentItem;
        if (serverSlot >= 0 && serverSlot != cur) mc.getConnection().sendPacket(new CPacketHeldItemChange(cur));
        serverSlot = cur;
    }

    /** Hotbar slot with the fastest tool that can harvest the block and beats the held item, or -1. */
    private int bestSlot(IBlockState state) {
        ItemStack held = mc.player.getHeldItemMainhand();
        // Client-side wear prediction could destroy a nearly broken held item locally; let vanilla handle it.
        if (held.isItemStackDamageable() && held.getMaxDamage() - held.getItemDamage() < 3) return -1;
        int cur = mc.player.inventory.currentItem;
        float bestSpeed = toolSpeed(held, state) + 0.001f;
        int best = -1;
        for (int i = 0; i < 9; i++) {
            if (i == cur) continue;
            ItemStack s = mc.player.inventory.getStackInSlot(i);
            if (s.isEmpty() || !canHarvest(s, state)) continue;
            if (s.isItemStackDamageable() && s.getItemDamage() >= s.getMaxDamage() - 1) continue;
            float sp = toolSpeed(s, state);
            if (sp > bestSpeed) {
                bestSpeed = sp;
                best = i;
            }
        }
        return best;
    }

    /** Destroy speed as vanilla computes it for the held item: base speed plus Efficiency. */
    private static float toolSpeed(ItemStack stack, IBlockState state) {
        float f = stack.getDestroySpeed(state);
        if (f > 1f) {
            int lvl = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack);
            if (lvl > 0) f += lvl * lvl + 1;
        }
        return f;
    }

    /** Same rules as ForgeHooks.canHarvestBlock, but for an arbitrary stack. */
    private boolean canHarvest(ItemStack stack, IBlockState state) {
        if (state.getMaterial().isToolNotRequired()) return true;
        String tool = state.getBlock().getHarvestTool(state);
        if (stack.isEmpty() || tool == null) return stack.canHarvestBlock(state);
        int lvl = stack.getItem().getHarvestLevel(stack, tool, mc.player, state);
        if (lvl < 0) return stack.canHarvestBlock(state);
        return lvl >= state.getBlock().getHarvestLevel(state);
    }
}
