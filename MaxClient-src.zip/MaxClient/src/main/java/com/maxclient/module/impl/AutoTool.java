package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

/**
 * Silent tool switch. While you mine with a sword in hand, the best hotbar tool for the block is selected
 * on the SERVER only (CPacketHeldItemChange). The client keeps the sword selected, so nothing changes in
 * your hand, the hotbar or the swing animation. The client mining progress uses the tool's real speed
 * (including Efficiency) through PlayerEvent.BreakSpeed, so breaking takes exactly as long as with that tool.
 */
public class AutoTool extends Module {
    private final BoolSetting onlySword = add(new BoolSetting("Only with sword", true));

    /** Slot the server currently believes is selected (-1 = unknown). */
    private int serverSlot = -1;
    private int lastCur = -1;
    private Object lastPlayer;

    public AutoTool() {
        super("Auto Tool", Category.PLAYER);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    protected void onDisable() {
        restore();
    }

    @SubscribeEvent
    public void onClientTickStart(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.START) update();
    }

    @SubscribeEvent
    public void onMouse(InputEvent.MouseInputEvent e) {
        if (Mouse.getEventButton() == 0 || Mouse.getEventDWheel() != 0) update();
    }

    /** Client-side mining speed of the tool that the server has selected. */
    @SubscribeEvent
    public void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        if (!isEnabled() || mc.player == null || e.getEntityPlayer() != mc.player || !mc.player.world.isRemote) return;
        IBlockState state = e.getState();
        int best = bestSlot(state);
        if (best < 0 || best != serverSlot) return;
        ItemStack held = mc.player.getHeldItemMainhand();
        ItemStack tool = mc.player.inventory.getStackInSlot(best);
        float heldBase = toolSpeed(held, state);
        if (heldBase <= 0f) return;
        float speed = e.getOriginalSpeed() / heldBase * toolSpeed(tool, state);
        // Vanilla divides progress by 30 if the held item can harvest the block, otherwise by 100.
        speed *= (canHarvest(held, state) ? 30f : 100f) / (canHarvest(tool, state) ? 30f : 100f);
        e.setNewSpeed(speed);
    }

    private void update() {
        if (mc.player == null || mc.world == null || mc.getConnection() == null) {
            serverSlot = -1;
            lastCur = -1;
            return;
        }
        if (mc.player != lastPlayer) {
            lastPlayer = mc.player;
            serverSlot = -1;
            lastCur = -1;
        }
        int cur = mc.player.inventory.currentItem;
        if (cur != lastCur) {
            lastCur = cur;
            serverSlot = -1;
        }
        if (serverSlot < 0) serverSlot = cur;

        int want = cur;
        if (isEnabled() && mc.currentScreen == null && !mc.playerController.isInCreativeMode()
                && mc.gameSettings.keyBindAttack.isKeyDown() && !mc.gameSettings.keyBindUseItem.isKeyDown()
                && mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK) {
            BlockPos pos = mc.objectMouseOver.getBlockPos();
            IBlockState state = mc.world.getBlockState(pos);
            if (state.getMaterial() != Material.AIR && state.getBlockHardness(mc.world, pos) >= 0f) {
                int best = bestSlot(state);
                if (best >= 0) want = best;
            }
        }
        if (want != serverSlot) {
            mc.getConnection().sendPacket(new CPacketHeldItemChange(want));
            serverSlot = want;
        }
    }

    /** Puts the server back on the slot the client actually has selected. */
    private void restore() {
        if (mc.player == null || mc.getConnection() == null) {
            serverSlot = -1;
            return;
        }
        int cur = mc.player.inventory.currentItem;
        if (serverSlot >= 0 && serverSlot != cur) mc.getConnection().sendPacket(new CPacketHeldItemChange(cur));
        serverSlot = cur;
    }

    /** Hotbar slot with the fastest tool that can harvest the block and beats the held item, or -1. */
    private int bestSlot(IBlockState state) {
        ItemStack held = mc.player.getHeldItemMainhand();
        if (onlySword.get() && !(held.getItem() instanceof ItemSword)) return -1;
        int cur = mc.player.inventory.currentItem;
        float bestSpeed = toolSpeed(held, state) + 0.001f;
        int best = -1;
        for (int i = 0; i < 9; i++) {
            if (i == cur) continue;
            ItemStack s = mc.player.inventory.getStackInSlot(i);
            if (s.isEmpty() || !canHarvest(s, state)) continue;
            if (s.isItemStackDamageable() && s.getItemDamage() >= s.getMaxDamage() - 1) continue;
            float sp = toolSpeed(s, state);
            if (sp > bestSpeed) {
                bestSpeed = sp;
                best = i;
            }
        }
        return best;
    }

    /** Destroy speed as vanilla computes it for the held item: base speed plus Efficiency. */
    private static float toolSpeed(ItemStack stack, IBlockState state) {
        float f = stack.getDestroySpeed(state);
        if (f > 1f) {
            int lvl = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack);
            if (lvl > 0) f += lvl * lvl + 1;
        }
        return f;
    }

    /** Same rules as ForgeHooks.canHarvestBlock, but for an arbitrary stack. */
    private boolean canHarvest(ItemStack stack, IBlockState state) {
        if (state.getMaterial().isToolNotRequired()) return true;
        String tool = state.getBlock().getHarvestTool(state);
        if (stack.isEmpty() || tool == null) return stack.canHarvestBlock(state);
        int lvl = stack.getItem().getHarvestLevel(stack, tool, mc.player, state);
        if (lvl < 0) return stack.canHarvestBlock(state);
        return lvl >= state.getBlock().getHarvestLevel(state);
    }
}
