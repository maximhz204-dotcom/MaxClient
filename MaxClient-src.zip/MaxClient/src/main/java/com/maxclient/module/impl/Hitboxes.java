package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;

import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Draws entity hitboxes and can enlarge them. The enlarged box is only active while a frame is rendered
 * (the crosshair target is computed there) and the vanilla box is restored at the end of the frame, so
 * physics, collisions and the game tick always see the unchanged vanilla hitbox.
 */
public class Hitboxes extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile mobs", true));
    private final BoolSetting passive = add(new BoolSetting("Passive mobs", true));
    private final NumberSetting expand = add(new NumberSetting("Expand", 0.25, 0, 1.0, 0.05));
    private final BoolSetting draw = add(new BoolSetting("Draw boxes", true));
    private final NumberSetting lineWidth = add(new NumberSetting("Line width", 2, 1, 5, 0.5));
    private final NumberSetting fill = add(new NumberSetting("Fill alpha", 30, 0, 120, 5));
    private final ColorSetting playerColor = add(new ColorSetting("Player color", 0.76f, 0.85f));
    private final ColorSetting hostileColor = add(new ColorSetting("Hostile color", 0.0f, 0.9f));
    private final ColorSetting passiveColor = add(new ColorSetting("Passive color", 0.33f, 0.8f));

    private final Map<Entity, AxisAlignedBB> originals = new IdentityHashMap<>();

    public Hitboxes() {
        super("Hitboxes", Category.COMBAT);
    }

    private boolean eligible(Entity e) {
        if (!(e instanceof EntityLivingBase) || e == mc.player || e instanceof EntityArmorStand || e.isDead) {
            return false;
        }
        if (e instanceof EntityPlayer) return players.get();
        if (e instanceof IMob) return hostile.get();
        return passive.get();
    }

    @Override
    public void onRenderStart(float pt) {
        double g = expand.get();
        if (g <= 0) return;
        for (Entity e : mc.world.loadedEntityList) {
            if (!eligible(e)) continue;
            AxisAlignedBB vanilla = e.getEntityBoundingBox();
            originals.put(e, vanilla);
            e.setEntityBoundingBox(vanilla.grow(g));
        }
    }

    @Override
    public void onRenderEnd() {
        if (originals.isEmpty()) return;
        for (Map.Entry<Entity, AxisAlignedBB> en : originals.entrySet()) {
            en.getKey().setEntityBoundingBox(en.getValue());
        }
        originals.clear();
    }

    @Override
    public void onRender3D(float pt) {
        if (!draw.get()) return;
        RenderUtil.begin3D(pt, lineWidth.getFloat());
        double k = 1.0 - pt;
        for (Entity e : mc.world.loadedEntityList) {
            if (!eligible(e)) continue;
            int rgb = e instanceof EntityPlayer ? playerColor.getRGB()
                    : e instanceof IMob ? hostileColor.getRGB() : passiveColor.getRGB();
            AxisAlignedBB bb = e.getEntityBoundingBox().offset((e.lastTickPosX - e.posX) * k,
                    (e.lastTickPosY - e.posY) * k, (e.lastTickPosZ - e.posZ) * k);
            RenderUtil.box(bb, rgb, fill.getInt(), 255);
        }
        RenderUtil.end3D();
    }
}
