package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;

public class Hitboxes extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile mobs", true));
    private final BoolSetting passive = add(new BoolSetting("Passive mobs", true));
    private final NumberSetting lineWidth = add(new NumberSetting("Line width", 2, 1, 5, 0.5));
    private final NumberSetting fill = add(new NumberSetting("Fill alpha", 30, 0, 120, 5));
    private final ColorSetting playerColor = add(new ColorSetting("Player color", 0.76f, 0.85f));
    private final ColorSetting hostileColor = add(new ColorSetting("Hostile color", 0.0f, 0.9f));
    private final ColorSetting passiveColor = add(new ColorSetting("Passive color", 0.33f, 0.8f));

    public Hitboxes() {
        super("Hitboxes", Category.COMBAT);
    }

    @Override
    public void onRender3D(float pt) {
        RenderUtil.begin3D(pt, lineWidth.getFloat());
        double k = 1.0 - pt;
        for (Entity e : mc.world.loadedEntityList) {
            if (!(e instanceof EntityLivingBase) || e == mc.player || e instanceof EntityArmorStand || e.isDead) continue;
            int rgb;
            if (e instanceof EntityPlayer) {
                if (!players.get()) continue;
                rgb = playerColor.getRGB();
            } else if (e instanceof IMob) {
                if (!hostile.get()) continue;
                rgb = hostileColor.getRGB();
            } else {
                if (!passive.get()) continue;
                rgb = passiveColor.getRGB();
            }
            AxisAlignedBB bb = e.getEntityBoundingBox().offset((e.lastTickPosX - e.posX) * k,
                    (e.lastTickPosY - e.posY) * k, (e.lastTickPosZ - e.posZ) * k);
            RenderUtil.box(bb, rgb, fill.getInt(), 255);
        }
        RenderUtil.end3D();
    }
}
