package com.maxclient.module.impl;

import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

/**
 * Draws entity hitboxes and enlarges the area in which the crosshair targets them. Entity bounding boxes are
 * never modified: after each rendered frame the module ray-traces against the enlarged boxes itself and, if
 * one is hit before the block/entity vanilla found, replaces mc.objectMouseOver. Rendering, physics and
 * collisions therefore stay exactly vanilla.
 */
public class Hitboxes extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile mobs", true));
    private final BoolSetting passive = add(new BoolSetting("Passive mobs", true));
    private final NumberSetting expand = add(new NumberSetting("Expand", 0.25, 0, 1.0, 0.05));
    private final BoolSetting draw = add(new BoolSetting("Draw boxes", true));
    private final NumberSetting lineWidth = add(new NumberSetting("Line width", 2, 1, 5, 0.5));
    private final NumberSetting fill = add(new NumberSetting("Fill alpha", 30, 0, 120, 5));
    private final ColorSetting playerColor = add(new ColorSetting("Player color", 0.76f, 0.85f));
    private final ColorSetting hostileColor = add(new ColorSetting("Hostile color", 0.0f, 0.9f));
    private final ColorSetting passiveColor = add(new ColorSetting("Passive color", 0.33f, 0.8f));

    public Hitboxes() {
        super("Hitboxes", Category.COMBAT);
    }

    private boolean eligible(Entity e) {
        if (!(e instanceof EntityLivingBase) || e == mc.player || e instanceof EntityArmorStand || e.isDead) {
            return false;
        }
        if (e instanceof EntityPlayer) return players.get();
        if (e instanceof IMob) return hostile.get();
        return passive.get();
    }

    /** Runs after each frame; the result is what the next game tick uses for attacks and TriggerBot. */
    @Override
    public void onRenderEnd() {
        double g = expand.get();
        Entity viewer = mc.getRenderViewEntity();
        if (g <= 0 || viewer == null || mc.currentScreen != null) return;
        float pt = mc.getRenderPartialTicks();
        double reach = mc.playerController.isInCreativeMode() ? 6.0 : 3.0;
        Vec3d eye = viewer.getPositionEyes(pt);
        Vec3d look = viewer.getLook(pt);
        Vec3d end = new Vec3d(eye.x + look.x * reach, eye.y + look.y * reach, eye.z + look.z * reach);

        double limit = reach * reach;
        RayTraceResult cur = mc.objectMouseOver;
        if (cur != null && cur.typeOfHit != RayTraceResult.Type.MISS && cur.hitVec != null) {
            limit = Math.min(limit, eye.squareDistanceTo(cur.hitVec));
        }
        Entity best = null;
        Vec3d bestHit = null;
        for (Entity e : mc.world.loadedEntityList) {
            if (!eligible(e) || !e.canBeCollidedWith() || e.getLowestRidingEntity() == viewer.getLowestRidingEntity()) {
                continue;
            }
            AxisAlignedBB bb = e.getEntityBoundingBox().grow(e.getCollisionBorderSize() + g);
            Vec3d hit;
            double d;
            if (bb.contains(eye)) {
                hit = eye;
                d = 0;
            } else {
                RayTraceResult r = bb.calculateIntercept(eye, end);
                if (r == null || r.hitVec == null) continue;
                hit = r.hitVec;
                d = eye.squareDistanceTo(hit);
            }
            if (d < limit) {
                limit = d;
                best = e;
                bestHit = hit;
            }
        }
        if (best != null) {
            mc.objectMouseOver = new RayTraceResult(best, bestHit);
            mc.pointedEntity = best;
        }
    }

    @Override
    public void onRender3D(float pt) {
        if (!draw.get()) return;
        RenderUtil.begin3D(pt, lineWidth.getFloat());
        double k = 1.0 - pt, g = expand.get();
        for (Entity e : mc.world.loadedEntityList) {
            if (!eligible(e)) continue;
            int rgb = e instanceof EntityPlayer ? playerColor.getRGB()
                    : e instanceof IMob ? hostileColor.getRGB() : passiveColor.getRGB();
            AxisAlignedBB bb = e.getEntityBoundingBox().offset((e.lastTickPosX - e.posX) * k,
                    (e.lastTickPosY - e.posY) * k, (e.lastTickPosZ - e.posZ) * k).grow(g);
            RenderUtil.box(bb, rgb, fill.getInt(), 255);
        }
        RenderUtil.end3D();
    }
}
