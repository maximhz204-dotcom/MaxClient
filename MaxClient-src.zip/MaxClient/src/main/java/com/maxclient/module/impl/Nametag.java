package com.maxclient.module.impl;

import com.maxclient.friend.FriendManager;
import com.maxclient.gui.Theme;
import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.module.ModuleManager;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * PvP nametag above other players: name, health (number + bar), distance, then one column per equipped item
 * (main hand, helmet, chestplate, leggings, boots, off hand) with the real item icon, durability percent and
 * enchantments. Everything is read from the players' actual equipment every frame. It works only while
 * Player ESP is on and takes its players from Player ESP; Player ESP then skips its own text tag.
 */
public class Nametag extends Module {
    private static final EntityEquipmentSlot[] ARMOR = {EntityEquipmentSlot.HEAD, EntityEquipmentSlot.CHEST,
            EntityEquipmentSlot.LEGS, EntityEquipmentSlot.FEET};
    private static final Map<String, String> SHORT = new HashMap<>();
    private static final int ICON = 12, ROW = 7, GAP = 2;
    private static final float SUB = 0.7f;

    static {
        String[] p = {"fire_protection", "FireP", "feather_falling", "Feather", "blast_protection", "BlastP",
                "projectile_protection", "ProjP", "respiration", "Resp", "aqua_affinity", "Aqua", "thorns", "Thorns",
                "depth_strider", "Depth", "frost_walker", "Frost", "binding_curse", "Bind", "sharpness", "Sharp",
                "smite", "Smite", "bane_of_arthropods", "Bane", "knockback", "KB", "fire_aspect", "Fire",
                "looting", "Loot", "sweeping", "Sweep", "efficiency", "Eff", "silk_touch", "Silk",
                "unbreaking", "Unb", "fortune", "Fort", "power", "Power", "punch", "Punch", "flame", "Flame",
                "infinity", "Inf", "luck_of_the_sea", "Luck", "lure", "Lure", "mending", "Mend",
                "vanishing_curse", "Van"};
        for (int i = 0; i < p.length; i += 2) SHORT.put(p[i], p[i + 1]);
    }

    private final BoolSetting nicks = add(new BoolSetting("Show Names", true));
    private final BoolSetting health = add(new BoolSetting("Show Health", true));
    private final BoolSetting distance = add(new BoolSetting("Show Distance", true));
    private final BoolSetting armor = add(new BoolSetting("Show Armor", true));
    private final BoolSetting mainHand = add(new BoolSetting("Show Items", true));
    private final BoolSetting offHand = add(new BoolSetting("Show Offhand", true));
    private final BoolSetting durability = add(new BoolSetting("Show Durability", true));
    private final BoolSetting enchants = add(new BoolSetting("Show Enchants", true));
    private final NumberSetting textSize = add(new NumberSetting("Text size", 0.7, 0.5, 2.0, 0.1));

    /** One equipped item: its stack plus the small texts under the icon. */
    private static final class Col {
        ItemStack stack;
        String dur;
        final List<String> ench = new ArrayList<>();
        int w;
    }

    public Nametag() {
        super("Nametag", Category.RENDER);
        MinecraftForge.EVENT_BUS.register(this);
    }

    /** True only while this module AND Player ESP are on. */
    public boolean isActive() {
        PlayerEsp esp = ModuleManager.get(PlayerEsp.class);
        return isEnabled() && esp != null && esp.isEnabled();
    }

    /** Hides the vanilla nameplate of players that this module labels instead. */
    @SubscribeEvent
    public void onVanillaNameplate(RenderLivingEvent.Specials.Pre event) {
        if (!isActive() || !nicks.get() || !(event.getEntity() instanceof EntityPlayer)) return;
        if (ModuleManager.get(PlayerEsp.class).players().contains(event.getEntity())) event.setCanceled(true);
    }

    @Override
    public void onRender3D(float pt) {
        if (!isActive()) return;
        List<EntityPlayer> players = ModuleManager.get(PlayerEsp.class).players();
        if (players.isEmpty()) return;
        double k = 1.0 - pt;
        RenderUtil.beginText3D(pt);
        for (EntityPlayer p : players) {
            AxisAlignedBB bb = PlayerEsp.box(p, k);
            // shrink when very close so the tag never blocks the view
            float near = Math.max(0.5f, Math.min(1f, mc.player.getDistance(p) / 4f));
            draw(p, (bb.minX + bb.maxX) / 2.0, bb.maxY + 0.25, (bb.minZ + bb.maxZ) / 2.0, textSize.getFloat() * near);
        }
        RenderUtil.end3D();
    }

    private void draw(EntityPlayer p, double wx, double wy, double wz, float size) {
        FontRenderer fr = mc.fontRenderer;
        String head = header(p);
        List<Col> cols = new ArrayList<>();
        if (mainHand.get()) addCol(cols, p.getHeldItemMainhand());
        if (armor.get()) {
            for (EntityEquipmentSlot slot : ARMOR) addCol(cols, p.getItemStackFromSlot(slot));
        }
        if (offHand.get()) addCol(cols, p.getHeldItemOffhand());

        boolean anyDur = false;
        int maxEnch = 0, colsW = cols.isEmpty() ? 0 : (cols.size() - 1) * GAP;
        for (Col c : cols) {
            anyDur |= c.dur != null;
            maxEnch = Math.max(maxEnch, c.ench.size());
            colsW += c.w;
        }
        boolean hasHead = !head.isEmpty();
        int h = (hasHead ? 10 : 0) + (health.get() ? 4 : 0)
                + (cols.isEmpty() ? 0 : ICON + 2 + (anyDur ? ROW : 0) + maxEnch * ROW);
        if (h == 0) return;
        int hw = hasHead ? fr.getStringWidth(head) : 0;
        int w = Math.max(Math.max(hw, colsW), 24);
        int y = -h;

        RenderUtil.pushTag(wx, wy, wz, size);
        Gui.drawRect(-w / 2 - 3, y - 2, w / 2 + 3, 1, 0x90000000);
        Gui.drawRect(-w / 2 - 3, y - 2, w / 2 + 3, y - 1, Theme.ACCENT);
        GlStateManager.enableBlend();
        if (hasHead) {
            fr.drawString(head, -hw / 2, y, 0xFFFFFFFF);
            y += 10;
        }
        if (health.get()) {
            drawBar(p, w, y);
            y += 4;
        }
        int x = -colsW / 2;
        for (Col c : cols) {
            drawCol(c, x, y);
            x += c.w + GAP;
        }
        RenderUtil.popTag();
    }

    /** "Name 20.0 2.0m" with the health number colored by how much health is left. */
    private String header(EntityPlayer p) {
        StringBuilder b = new StringBuilder();
        if (nicks.get()) b.append(FriendManager.isFriend(p.getName()) ? "\u00a7a" : "\u00a7f").append(p.getName());
        if (health.get()) {
            float ratio = p.getHealth() / Math.max(1f, p.getMaxHealth());
            if (b.length() > 0) b.append(' ');
            b.append(ratio > 0.66f ? "\u00a7a" : ratio > 0.33f ? "\u00a7e" : "\u00a7c")
                    .append(String.format(Locale.ROOT, "%.1f", p.getHealth() + p.getAbsorptionAmount()));
        }
        if (distance.get()) {
            if (b.length() > 0) b.append(' ');
            b.append("\u00a77").append(String.format(Locale.ROOT, "%.1fm", mc.player.getDistance(p)));
        }
        return b.toString();
    }

    private void drawBar(EntityPlayer p, int w, int y) {
        float ratio = Math.max(0f, Math.min(1f, p.getHealth() / Math.max(1f, p.getMaxHealth())));
        int color = ratio > 0.66f ? 0xFF55FF55 : ratio > 0.33f ? 0xFFFFFF55 : 0xFFFF5555;
        Gui.drawRect(-w / 2, y, w / 2, y + 2, 0xFF2A2A2A);
        Gui.drawRect(-w / 2, y, -w / 2 + Math.round(w * ratio), y + 2, color);
        GlStateManager.enableBlend();
    }

    /** Reads the real stack: durability percent (green 70-100, yellow 30-69, red 0-29) and its enchantments. */
    private void addCol(List<Col> cols, ItemStack s) {
        if (s.isEmpty()) return;
        FontRenderer fr = mc.fontRenderer;
        Col c = new Col();
        c.stack = s;
        int textW = 0;
        if (durability.get() && s.isItemStackDamageable()) {
            int pct = Math.max(0, Math.min(100, Math.round(100f * (s.getMaxDamage() - s.getItemDamage()) / s.getMaxDamage())));
            c.dur = (pct >= 70 ? "\u00a7a" : pct >= 30 ? "\u00a7e" : "\u00a7c") + pct + "%";
            textW = fr.getStringWidth(c.dur);
        }
        if (enchants.get()) {
            for (Map.Entry<Enchantment, Integer> e : EnchantmentHelper.getEnchantments(s).entrySet()) {
                String t = (e.getKey().isCurse() ? "\u00a7c" : "\u00a7b") + shortName(e.getKey(), e.getValue());
                c.ench.add(t);
                textW = Math.max(textW, fr.getStringWidth(t));
            }
        }
        c.w = Math.max(ICON + 2, Math.round(textW * SUB) + 2);
        cols.add(c);
    }

    /** Icon through the game's own item renderer, then count, durability and enchantments under it. */
    private void drawCol(Col c, int x, int y) {
        float cx = x + c.w / 2f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx - ICON / 2f, y, 0f);
        GlStateManager.scale(ICON / 16f, ICON / 16f, 0.001f); // flat: keeps the icon from jumping toward the camera
        RenderHelper.enableGUIStandardItemLighting();
        mc.getRenderItem().renderItemAndEffectIntoGUI(c.stack, 0, 0);
        RenderHelper.disableStandardItemLighting();
        GlStateManager.popMatrix();
        GlStateManager.enableBlend();
        if (c.stack.getCount() > 1) sub("\u00a7fx" + c.stack.getCount(), cx + ICON / 2f, y + ICON - 5, true);
        float ty = y + ICON + 2;
        if (c.dur != null) {
            sub(c.dur, cx, ty, false);
            ty += ROW;
        }
        for (String e : c.ench) {
            sub(e, cx, ty, false);
            ty += ROW;
        }
    }

    private void sub(String text, float x, float y, boolean right) {
        FontRenderer fr = mc.fontRenderer;
        int w = fr.getStringWidth(text);
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0f);
        GlStateManager.scale(SUB, SUB, 1f);
        fr.drawString(text, right ? -w : -w / 2, 0, 0xFFFFFFFF, true);
        GlStateManager.popMatrix();
    }

    /** Protection is "Z1".."Z4" (the real level); single-level enchantments have no number. */
    private static String shortName(Enchantment en, int level) {
        String full = en.getRegistryName() == null ? "" : en.getRegistryName().toString();
        String path = full.substring(full.indexOf(':') + 1);
        if (path.equals("protection")) return "Z" + level;
        String name = SHORT.get(path);
        if (name == null) {
            name = path.isEmpty() ? "?" : Character.toUpperCase(path.charAt(0)) + path.substring(1, Math.min(4, path.length()));
        }
        return en.getMaxLevel() == 1 ? name : name + level;
    }
}
