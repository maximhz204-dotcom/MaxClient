package com.maxclient.module.impl;

import com.maxclient.friend.FriendManager;
import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.module.ModuleManager;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.util.RenderUtil;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Info tag above other players: nick, armor, main hand, off hand, enchantments, item names and stack counts.
 * It works only while Player ESP is enabled and takes its players from Player ESP (no second player search).
 * While active, the vanilla nameplate of those players is hidden so the nick appears once.
 */
public class Nametag extends Module {
    private static final EntityEquipmentSlot[] ARMOR = {EntityEquipmentSlot.HEAD, EntityEquipmentSlot.CHEST,
            EntityEquipmentSlot.LEGS, EntityEquipmentSlot.FEET};
    private static final Map<String, String> SHORT = new HashMap<>();

    static {
        String[] p = {"protection", "Prot", "fire_protection", "FireP", "feather_falling", "Feather",
                "blast_protection", "BlastP", "projectile_protection", "ProjP", "respiration", "Resp",
                "aqua_affinity", "Aqua", "thorns", "Thorns", "depth_strider", "Depth", "frost_walker", "Frost",
                "binding_curse", "Bind", "sharpness", "Sharp", "smite", "Smite", "bane_of_arthropods", "Bane",
                "knockback", "KB", "fire_aspect", "Fire", "looting", "Loot", "sweeping", "Sweep",
                "efficiency", "Eff", "silk_touch", "Silk", "unbreaking", "Unb", "fortune", "Fort",
                "power", "Power", "punch", "Punch", "flame", "Flame", "infinity", "Inf",
                "luck_of_the_sea", "Luck", "lure", "Lure", "mending", "Mend", "vanishing_curse", "Van"};
        for (int i = 0; i < p.length; i += 2) SHORT.put(p[i], p[i + 1]);
    }

    private final BoolSetting nicks = add(new BoolSetting("Show Names", true));
    private final BoolSetting armor = add(new BoolSetting("Show Armor", true));
    private final BoolSetting mainHand = add(new BoolSetting("Show Items", true));
    private final BoolSetting offHand = add(new BoolSetting("Show Offhand", true));
    private final BoolSetting enchants = add(new BoolSetting("Show Enchants", true));
    private final NumberSetting textSize = add(new NumberSetting("Text size", 0.9, 0.5, 2.0, 0.1));

    public Nametag() {
        super("Nametag", Category.RENDER);
        MinecraftForge.EVENT_BUS.register(this);
    }

    /** True only while this module AND Player ESP are on. */
    public boolean isActive() {
        PlayerEsp esp = ModuleManager.get(PlayerEsp.class);
        return isEnabled() && esp != null && esp.isEnabled();
    }

    public boolean showsNicks() {
        return nicks.get();
    }

    /** Hides the vanilla nameplate of players that this module labels instead. */
    @SubscribeEvent
    public void onVanillaNameplate(RenderLivingEvent.Specials.Pre event) {
        if (!isActive() || !nicks.get() || !(event.getEntity() instanceof EntityPlayer)) return;
        if (ModuleManager.get(PlayerEsp.class).players().contains(event.getEntity())) event.setCanceled(true);
    }

    @Override
    public void onRender3D(float pt) {
        if (!isActive()) return;
        PlayerEsp esp = ModuleManager.get(PlayerEsp.class);
        List<EntityPlayer> players = esp.players();
        if (players.isEmpty()) return;

        float size = textSize.getFloat();
        int espLines = esp.tagLineCount();
        // stand above the Player ESP tag: its height in tag units, converted to this tag's text size
        float lift = espLines == 0 ? 0f : (espLines * 10f + 4f) * esp.tagTextSize() / size;
        double k = 1.0 - pt;

        RenderUtil.beginText3D(pt);
        for (EntityPlayer p : players) {
            List<String> lines = lines(p);
            if (lines.isEmpty()) continue;
            AxisAlignedBB bb = PlayerEsp.box(p, k);
            RenderUtil.drawTag((bb.minX + bb.maxX) / 2.0, bb.maxY + 0.25, (bb.minZ + bb.maxZ) / 2.0,
                    lines.toArray(new String[0]), 0xFFFFFFFF, size, lift);
        }
        RenderUtil.end3D();
    }

    private List<String> lines(EntityPlayer p) {
        List<String> lines = new ArrayList<>();
        if (nicks.get()) lines.add((FriendManager.isFriend(p.getName()) ? "\u00a7a" : "\u00a7f") + p.getName());
        if (mainHand.get()) addItem(lines, p.getHeldItemMainhand(), "\u00a77[Main] ");
        if (offHand.get()) addItem(lines, p.getHeldItemOffhand(), "\u00a77[Off] ");
        if (armor.get()) {
            for (EntityEquipmentSlot slot : ARMOR) addItem(lines, p.getItemStackFromSlot(slot), "");
        }
        return lines;
    }

    /** One line per item: name (rarity color), count if above one, enchantments if enabled. */
    private void addItem(List<String> lines, ItemStack s, String prefix) {
        if (s.isEmpty()) return;
        StringBuilder b = new StringBuilder(prefix);
        b.append(rarityCode(s)).append(s.getDisplayName());
        if (s.getCount() > 1) b.append(" \u00a77x").append(s.getCount());
        if (enchants.get()) {
            for (Map.Entry<Enchantment, Integer> e : EnchantmentHelper.getEnchantments(s).entrySet()) {
                Enchantment en = e.getKey();
                b.append(' ').append(en.isCurse() ? "\u00a7c" : "\u00a7b").append(shortName(en, e.getValue()));
            }
        }
        lines.add(b.toString());
    }

    /** Vanilla rarity colors by order: common white, uncommon yellow, rare aqua, epic light purple. */
    private static String rarityCode(ItemStack s) {
        switch (s.getRarity().ordinal()) {
            case 1: return "\u00a7e";
            case 2: return "\u00a7b";
            case 3: return "\u00a7d";
            default: return "\u00a7f";
        }
    }

    /** "Sharp5", "Mend" (single-level enchantments have no number), unknown ones get their first letters. */
    private static String shortName(Enchantment en, int level) {
        String full = en.getRegistryName() == null ? "" : en.getRegistryName().toString();
        String path = full.substring(full.indexOf(':') + 1);
        String name = SHORT.get(path);
        if (name == null) {
            name = path.isEmpty() ? "?" : Character.toUpperCase(path.charAt(0)) + path.substring(1, Math.min(4, path.length()));
        }
        return en.getMaxLevel() == 1 ? name : name + level;
    }
}
