package com.maxclient.module.impl;

import java.util.Locale;

public class CoordsHud extends TextHud {
    public CoordsHud() {
        super("Coordinates", 4, 16);
    }

    @Override
    protected String text() {
        return String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", mc.player.posX, mc.player.posY, mc.player.posZ);
    }
}
