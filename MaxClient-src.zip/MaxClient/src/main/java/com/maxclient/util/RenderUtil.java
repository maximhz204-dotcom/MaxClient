package com.maxclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

public final class RenderUtil {
    private static double vx, vy, vz;

    private RenderUtil() {}

    public static void begin3D(float pt, float lineWidth) {
        Minecraft mc = Minecraft.getMinecraft();
        Entity v = mc.getRenderViewEntity() != null ? mc.getRenderViewEntity() : mc.player;
        vx = v.lastTickPosX + (v.posX - v.lastTickPosX) * pt;
        vy = v.lastTickPosY + (v.posY - v.lastTickPosY) * pt;
        vz = v.lastTickPosZ + (v.posZ - v.lastTickPosZ) * pt;
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.disableAlpha();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
                GlStateManager.DestFactor.ZERO);
        GlStateManager.depthMask(false);
        GL11.glLineWidth(lineWidth);
    }

    public static void end3D() {
        GL11.glLineWidth(1f);
        GlStateManager.depthMask(true);
        GlStateManager.enableDepth();
        GlStateManager.enableCull();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    /** World-space box; drawn through blocks (depth test is off in begin3D). */
    public static void box(AxisAlignedBB bb, int rgb, int fillAlpha, int lineAlpha) {
        double[] xs = {bb.minX - vx, bb.maxX - vx};
        double[] ys = {bb.minY - vy, bb.maxY - vy};
        double[] zs = {bb.minZ - vz, bb.maxZ - vz};
        Tessellator t = Tessellator.getInstance();
        BufferBuilder b = t.getBuffer();
        if (fillAlpha > 0) {
            int c = (fillAlpha << 24) | (rgb & 0xFFFFFF);
            b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i < 2; i++) {
                quad(b, c, xs[i], ys[0], zs[0], xs[i], ys[1], zs[0], xs[i], ys[1], zs[1], xs[i], ys[0], zs[1]);
                quad(b, c, xs[0], ys[i], zs[0], xs[1], ys[i], zs[0], xs[1], ys[i], zs[1], xs[0], ys[i], zs[1]);
                quad(b, c, xs[0], ys[0], zs[i], xs[1], ys[0], zs[i], xs[1], ys[1], zs[i], xs[0], ys[1], zs[i]);
            }
            t.draw();
        }
        if (lineAlpha > 0) {
            int c = (lineAlpha << 24) | (rgb & 0xFFFFFF);
            b.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
            for (int j = 0; j < 2; j++) {
                for (int k = 0; k < 2; k++) {
                    vertex(b, c, xs[0], ys[j], zs[k]); vertex(b, c, xs[1], ys[j], zs[k]);
                    vertex(b, c, xs[j], ys[0], zs[k]); vertex(b, c, xs[j], ys[1], zs[k]);
                    vertex(b, c, xs[j], ys[k], zs[0]); vertex(b, c, xs[j], ys[k], zs[1]);
                }
            }
            t.draw();
        }
    }

    /** 2D horizontal gradient, ARGB colors. */
    public static void hGradient(int x1, int y1, int x2, int y2, int c1, int c2) {
        if (x2 <= x1 || y2 <= y1) return;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
                GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);
        Tessellator t = Tessellator.getInstance();
        BufferBuilder b = t.getBuffer();
        b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        vertex(b, c2, x2, y1, 0);
        vertex(b, c1, x1, y1, 0);
        vertex(b, c1, x1, y2, 0);
        vertex(b, c2, x2, y2, 0);
        t.draw();
        GlStateManager.shadeModel(GL11.GL_FLAT);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    private static void quad(BufferBuilder b, int c, double ax, double ay, double az, double bx, double by,
                             double bz, double cx, double cy, double cz, double dx, double dy, double dz) {
        vertex(b, c, ax, ay, az);
        vertex(b, c, bx, by, bz);
        vertex(b, c, cx, cy, cz);
        vertex(b, c, dx, dy, dz);
    }

    private static void vertex(BufferBuilder b, int c, double x, double y, double z) {
        b.pos(x, y, z).color(c >> 16 & 255, c >> 8 & 255, c & 255, c >>> 24).endVertex();
    }
}
