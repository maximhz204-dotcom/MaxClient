package com.maxclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

public final class RenderUtil {
    private static double vx, vy, vz;

    private RenderUtil() {}

    /**
     * Prepares world-space drawing through blocks. All GL state is saved with glPushAttrib and restored in
     * end3D, so nothing leaks into later vanilla rendering (lighting, fog, alpha, depth, blend).
     */
    public static void begin3D(float pt, float lineWidth) {
        Minecraft mc = Minecraft.getMinecraft();
        Entity v = mc.getRenderViewEntity() != null ? mc.getRenderViewEntity() : mc.player;
        vx = v.lastTickPosX + (v.posX - v.lastTickPosX) * pt;
        vy = v.lastTickPosY + (v.posY - v.lastTickPosY) * pt;
        vz = v.lastTickPosZ + (v.posZ - v.lastTickPosZ) * pt;
        GL11.glPushAttrib(GL11.GL_ENABLE_BIT | GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT
                | GL11.GL_LINE_BIT | GL11.GL_CURRENT_BIT);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_CULL_FACE);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glDisable(GL11.GL_FOG);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDepthMask(false);
        GL11.glLineWidth(lineWidth);
    }

    public static void end3D() {
        GL11.glPopAttrib();
    }

    /** Single box (few objects). For many boxes use the batch methods below. */
    public static void box(AxisAlignedBB bb, int rgb, int fillAlpha, int lineAlpha) {
        if (fillAlpha > 0) {
            beginQuads();
            quadBox(bb, rgb, fillAlpha);
            endBatch();
        }
        if (lineAlpha > 0) {
            beginLines();
            lineBox(bb, rgb, lineAlpha);
            endBatch();
        }
    }

    public static void beginQuads() {
        Tessellator.getInstance().getBuffer().begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
    }

    public static void beginLines() {
        Tessellator.getInstance().getBuffer().begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
    }

    public static void endBatch() {
        Tessellator.getInstance().draw();
    }

    public static void quadBox(AxisAlignedBB bb, int rgb, int alpha) {
        quadBox(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ, rgb, alpha);
    }

    public static void lineBox(AxisAlignedBB bb, int rgb, int alpha) {
        lineBox(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ, rgb, alpha);
    }

    /** Filled box in world coordinates; call between beginQuads() and endBatch(). */
    public static void quadBox(double ax, double ay, double az, double bx, double by, double bz, int rgb, int alpha) {
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        int c = (alpha << 24) | (rgb & 0xFFFFFF);
        double x1 = ax - vx, y1 = ay - vy, z1 = az - vz, x2 = bx - vx, y2 = by - vy, z2 = bz - vz;
        quad(b, c, x1, y1, z1, x1, y2, z1, x1, y2, z2, x1, y1, z2);
        quad(b, c, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2);
        quad(b, c, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2);
        quad(b, c, x1, y2, z1, x2, y2, z1, x2, y2, z2, x1, y2, z2);
        quad(b, c, x1, y1, z1, x2, y1, z1, x2, y2, z1, x1, y2, z1);
        quad(b, c, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2);
    }

    /** Box outline in world coordinates; call between beginLines() and endBatch(). */
    public static void lineBox(double ax, double ay, double az, double bx, double by, double bz, int rgb, int alpha) {
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        int c = (alpha << 24) | (rgb & 0xFFFFFF);
        double x1 = ax - vx, y1 = ay - vy, z1 = az - vz, x2 = bx - vx, y2 = by - vy, z2 = bz - vz;
        line(b, c, x1, y1, z1, x2, y1, z1);
        line(b, c, x2, y1, z1, x2, y1, z2);
        line(b, c, x2, y1, z2, x1, y1, z2);
        line(b, c, x1, y1, z2, x1, y1, z1);
        line(b, c, x1, y2, z1, x2, y2, z1);
        line(b, c, x2, y2, z1, x2, y2, z2);
        line(b, c, x2, y2, z2, x1, y2, z2);
        line(b, c, x1, y2, z2, x1, y2, z1);
        line(b, c, x1, y1, z1, x1, y2, z1);
        line(b, c, x2, y1, z1, x2, y2, z1);
        line(b, c, x2, y1, z2, x2, y2, z2);
        line(b, c, x1, y1, z2, x1, y2, z2);
    }

    /** 2D horizontal gradient, ARGB colors. */
    public static void hGradient(int x1, int y1, int x2, int y2, int c1, int c2) {
        if (x2 <= x1 || y2 <= y1) return;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
                GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);
        Tessellator t = Tessellator.getInstance();
        BufferBuilder b = t.getBuffer();
        b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        vertex(b, c2, x2, y1, 0);
        vertex(b, c1, x1, y1, 0);
        vertex(b, c1, x1, y2, 0);
        vertex(b, c2, x2, y2, 0);
        t.draw();
        GlStateManager.shadeModel(GL11.GL_FLAT);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    private static void quad(BufferBuilder b, int c, double ax, double ay, double az, double bx, double by,
                             double bz, double cx, double cy, double cz, double dx, double dy, double dz) {
        vertex(b, c, ax, ay, az);
        vertex(b, c, bx, by, bz);
        vertex(b, c, cx, cy, cz);
        vertex(b, c, dx, dy, dz);
    }

    private static void line(BufferBuilder b, int c, double ax, double ay, double az, double bx, double by,
                             double bz) {
        vertex(b, c, ax, ay, az);
        vertex(b, c, bx, by, bz);
    }

    private static void vertex(BufferBuilder b, int c, double x, double y, double z) {
        b.pos(x, y, z).color(c >> 16 & 255, c >> 8 & 255, c & 255, c >>> 24).endVertex();
    }
}
