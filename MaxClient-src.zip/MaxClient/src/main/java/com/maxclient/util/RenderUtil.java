package com.maxclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

public final class RenderUtil {
    private static double vx, vy, vz;

    private RenderUtil() {}

    private static boolean sTex, sDepth, sLight, sCull, sAlpha, sFog, sBlend;

    /**
     * Prepares world-space drawing through blocks. Every state that is changed here is read first and put back
     * in end3D, and only GlStateManager is used, so its internal state cache never gets out of sync with OpenGL
     * (a desynced cache is what leaves entities untextured on some mobile renderers).
     */
    public static void begin3D(float pt, float lineWidth) {
        Minecraft mc = Minecraft.getMinecraft();
        Entity v = mc.getRenderViewEntity() != null ? mc.getRenderViewEntity() : mc.player;
        vx = v.lastTickPosX + (v.posX - v.lastTickPosX) * pt;
        vy = v.lastTickPosY + (v.posY - v.lastTickPosY) * pt;
        vz = v.lastTickPosZ + (v.posZ - v.lastTickPosZ) * pt;
        sTex = GL11.glIsEnabled(GL11.GL_TEXTURE_2D);
        sDepth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        sLight = GL11.glIsEnabled(GL11.GL_LIGHTING);
        sCull = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        sAlpha = GL11.glIsEnabled(GL11.GL_ALPHA_TEST);
        sFog = GL11.glIsEnabled(GL11.GL_FOG);
        sBlend = GL11.glIsEnabled(GL11.GL_BLEND);
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.disableAlpha();
        GlStateManager.disableFog();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
                GlStateManager.DestFactor.ZERO);
        GlStateManager.depthMask(false);
        GL11.glLineWidth(lineWidth);
    }

    public static void end3D() {
        GL11.glLineWidth(1f);
        GlStateManager.depthMask(true);
        if (sTex) GlStateManager.enableTexture2D(); else GlStateManager.disableTexture2D();
        if (sDepth) GlStateManager.enableDepth(); else GlStateManager.disableDepth();
        if (sLight) GlStateManager.enableLighting(); else GlStateManager.disableLighting();
        if (sCull) GlStateManager.enableCull(); else GlStateManager.disableCull();
        if (sAlpha) GlStateManager.enableAlpha(); else GlStateManager.disableAlpha();
        if (sFog) GlStateManager.enableFog(); else GlStateManager.disableFog();
        if (sBlend) GlStateManager.enableBlend(); else GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    /** Single box (few objects). For many boxes use the batch methods below. */
    public static void box(AxisAlignedBB bb, int rgb, int fillAlpha, int lineAlpha) {
        if (fillAlpha > 0) {
            beginQuads();
            quadBox(bb, rgb, fillAlpha);
            endBatch();
        }
        if (lineAlpha > 0) {
            beginLines();
            lineBox(bb, rgb, lineAlpha);
            endBatch();
        }
    }

    public static void beginQuads() {
        Tessellator.getInstance().getBuffer().begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
    }

    public static void beginLines() {
        Tessellator.getInstance().getBuffer().begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
    }

    public static void endBatch() {
        Tessellator.getInstance().draw();
    }

    public static void quadBox(AxisAlignedBB bb, int rgb, int alpha) {
        quadBox(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ, rgb, alpha);
    }

    public static void lineBox(AxisAlignedBB bb, int rgb, int alpha) {
        lineBox(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ, rgb, alpha);
    }

    /** Filled box in world coordinates; call between beginQuads() and endBatch(). */
    public static void quadBox(double ax, double ay, double az, double bx, double by, double bz, int rgb, int alpha) {
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        int c = (alpha << 24) | (rgb & 0xFFFFFF);
        double x1 = ax - vx, y1 = ay - vy, z1 = az - vz, x2 = bx - vx, y2 = by - vy, z2 = bz - vz;
        quad(b, c, x1, y1, z1, x1, y2, z1, x1, y2, z2, x1, y1, z2);
        quad(b, c, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2);
        quad(b, c, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2);
        quad(b, c, x1, y2, z1, x2, y2, z1, x2, y2, z2, x1, y2, z2);
        quad(b, c, x1, y1, z1, x2, y1, z1, x2, y2, z1, x1, y2, z1);
        quad(b, c, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2);
    }

    /** Box outline in world coordinates; call between beginLines() and endBatch(). */
    public static void lineBox(double ax, double ay, double az, double bx, double by, double bz, int rgb, int alpha) {
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        int c = (alpha << 24) | (rgb & 0xFFFFFF);
        double x1 = ax - vx, y1 = ay - vy, z1 = az - vz, x2 = bx - vx, y2 = by - vy, z2 = bz - vz;
        line(b, c, x1, y1, z1, x2, y1, z1);
        line(b, c, x2, y1, z1, x2, y1, z2);
        line(b, c, x2, y1, z2, x1, y1, z2);
        line(b, c, x1, y1, z2, x1, y1, z1);
        line(b, c, x1, y2, z1, x2, y2, z1);
        line(b, c, x2, y2, z1, x2, y2, z2);
        line(b, c, x2, y2, z2, x1, y2, z2);
        line(b, c, x1, y2, z2, x1, y2, z1);
        line(b, c, x1, y1, z1, x1, y2, z1);
        line(b, c, x2, y1, z1, x2, y2, z1);
        line(b, c, x2, y1, z2, x2, y2, z2);
        line(b, c, x1, y1, z2, x1, y2, z2);
    }

    /** 2D horizontal gradient, ARGB colors. */
    public static void hGradient(int x1, int y1, int x2, int y2, int c1, int c2) {
        if (x2 <= x1 || y2 <= y1) return;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
                GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);
        Tessellator t = Tessellator.getInstance();
        BufferBuilder b = t.getBuffer();
        b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        vertex(b, c2, x2, y1, 0);
        vertex(b, c1, x1, y1, 0);
        vertex(b, c1, x1, y2, 0);
        vertex(b, c2, x2, y2, 0);
        t.draw();
        GlStateManager.shadeModel(GL11.GL_FLAT);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    private static void quad(BufferBuilder b, int c, double ax, double ay, double az, double bx, double by,
                             double bz, double cx, double cy, double cz, double dx, double dy, double dz) {
        vertex(b, c, ax, ay, az);
        vertex(b, c, bx, by, bz);
        vertex(b, c, cx, cy, cz);
        vertex(b, c, dx, dy, dz);
    }

    private static void line(BufferBuilder b, int c, double ax, double ay, double az, double bx, double by,
                             double bz) {
        vertex(b, c, ax, ay, az);
        vertex(b, c, bx, by, bz);
    }

    private static void vertex(BufferBuilder b, int c, double x, double y, double z) {
        b.pos(x, y, z).color(c >> 16 & 255, c >> 8 & 255, c & 255, c >>> 24).endVertex();
    }
}
