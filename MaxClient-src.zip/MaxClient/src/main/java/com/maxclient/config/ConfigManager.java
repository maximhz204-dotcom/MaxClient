package com.maxclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.maxclient.MaxClient;
import com.maxclient.module.Module;
import com.maxclient.module.ModuleManager;
import com.maxclient.setting.Setting;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ConfigManager() {}

    private static File file() {
        return new File(net.minecraftforge.fml.common.Loader.instance().getConfigDir(), "maxclient.json");
    }

    public static void save() {
        JsonObject root = new JsonObject();
        for (Module m : ModuleManager.all()) {
            JsonObject mo = new JsonObject();
            mo.addProperty("enabled", m.isEnabled());
            JsonObject so = new JsonObject();
            for (Setting s : m.settings) so.add(s.name, s.toJson());
            mo.add("settings", so);
            root.add(m.name, mo);
        }
        File f = file();
        f.getParentFile().mkdirs();
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) {
            GSON.toJson(root, w);
        } catch (IOException e) {
            MaxClient.LOG.error("Failed to save config", e);
        }
    }

    public static void load() {
        File f = file();
        if (!f.isFile()) return;
        try (Reader r = new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8)) {
            JsonObject root = new JsonParser().parse(r).getAsJsonObject();
            for (Module m : ModuleManager.all()) {
                JsonElement me = root.get(m.name);
                if (me == null || !me.isJsonObject()) continue;
                JsonObject mo = me.getAsJsonObject();
                JsonElement se = mo.get("settings");
                if (se != null && se.isJsonObject()) {
                    JsonObject so = se.getAsJsonObject();
                    for (Setting s : m.settings) {
                        if (!so.has(s.name)) continue;
                        try {
                            s.fromJson(so.get(s.name));
                        } catch (RuntimeException ex) {
                            MaxClient.LOG.warn("Bad setting {}.{}", m.name, s.name);
                        }
                    }
                }
                if (mo.has("enabled")) m.setEnabled(mo.get("enabled").getAsBoolean());
            }
        } catch (IOException | RuntimeException e) {
            MaxClient.LOG.error("Failed to load config", e);
        }
    }
}
