package com.maxclient.gui;

/** Black + purple palette (ARGB) and color helpers. */
public final class Theme {
    public static final int PANEL_BG = 0xE60B0B10;
    public static final int HEADER_BG = 0xF0140A24;
    public static final int ROW_BG = 0xE6111117;
    public static final int ROW_HOVER = 0xE61E1230;
    public static final int SET_BG = 0xE60A0A0F;
    public static final int ACCENT = 0xFF9B30FF;
    public static final int ACCENT_DARK = 0xFF4B0F8F;
    public static final int TEXT = 0xFFEEE6FF;
    public static final int DIM = 0xFF8F86A8;
    public static final int OFF = 0xFF2A2338;

    /** Global fade used by the open animation. */
    public static float alpha = 1f;

    private Theme() {}

    public static int fade(int c) { return scaleAlpha(c, alpha); }

    public static int scaleAlpha(int c, float f) {
        int a = Math.max(0, Math.min(255, Math.round((c >>> 24) * f)));
        return (a << 24) | (c & 0xFFFFFF);
    }

    public static int mix(int c1, int c2, float t) {
        int r = 0;
        for (int s = 24; s >= 0; s -= 8) {
            int a = c1 >>> s & 255, b = c2 >>> s & 255;
            r |= (a + Math.round((b - a) * t)) << s;
        }
        return r;
    }
}
