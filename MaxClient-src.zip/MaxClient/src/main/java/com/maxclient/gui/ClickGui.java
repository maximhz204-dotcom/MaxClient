package com.maxclient.gui;

import com.maxclient.MaxClient;
import com.maxclient.config.ConfigManager;
import com.maxclient.module.Category;
import com.maxclient.module.Module;
import com.maxclient.module.ModuleManager;
import com.maxclient.setting.BoolSetting;
import com.maxclient.setting.ColorSetting;
import com.maxclient.setting.ModeSetting;
import com.maxclient.setting.NumberSetting;
import com.maxclient.setting.Setting;
import com.maxclient.util.RenderUtil;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.Collections;
import java.util.EnumMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ClickGui extends GuiScreen {
    private static final int HEADER = 20, ROW = 16, BOOL_H = 15, NUM_H = 22, COL_H = 32, GAP = 8, TOP = 30;

    private final Map<Object, Float> toggleAnim = new IdentityHashMap<>();
    private final Map<Object, Float> hoverAnim = new IdentityHashMap<>();
    private final Map<Object, Float> expandAnim = new IdentityHashMap<>();
    private final Set<Module> expanded = Collections.newSetFromMap(new IdentityHashMap<Module, Boolean>());
    private final Map<Category, Float> scroll = new EnumMap<>(Category.class);
    private final Map<Category, Float> maxScroll = new EnumMap<>(Category.class);
    private final Map<Category, Integer> panelX = new EnumMap<>(Category.class);
    private int panelW;

    private long openTime = System.nanoTime(), lastFrame = openTime;
    private float dt;
    private int sf = 1;
    private int clipX1, clipY1, clipX2, clipY2;

    private Setting dragging;
    private int dragBar, dragX, dragW;
    private int clickX, clickY, clickBtn = -1;

    @Override
    public void initGui() {
        openTime = lastFrame = System.nanoTime();
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    @Override
    public void onGuiClosed() { ConfigManager.save(); }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == MaxClient.openKey.getKeyCode()) {
            mc.displayGuiScreen(null);
            return;
        }
        super.keyTyped(c, key);
    }

    @Override
    protected void mouseClicked(int x, int y, int btn) {
        clickX = x;
        clickY = y;
        clickBtn = btn;
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d == 0) return;
        int mx = Mouse.getEventX() * width / mc.displayWidth;
        for (Category c : Category.values()) {
            Integer px = panelX.get(c);
            if (px == null || mx < px || mx >= px + panelW) continue;
            float cur = scroll.containsKey(c) ? scroll.get(c) : 0f;
            float max = maxScroll.containsKey(c) ? maxScroll.get(c) : 0f;
            scroll.put(c, Math.max(0f, Math.min(max, cur - Math.signum((float) d) * 20f)));
        }
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        long now = System.nanoTime();
        dt = Math.min((now - lastFrame) / 1.0e9f, 0.1f);
        lastFrame = now;
        float p = Math.min(1f, (now - openTime) / 2.5e8f);
        float open = 1f - (1f - p) * (1f - p) * (1f - p);
        Theme.alpha = open;
        sf = new ScaledResolution(mc).getScaleFactor();
        if (dragging != null && !Mouse.isButtonDown(0)) dragging = null;

        Gui.drawRect(0, 0, width, height, Theme.fade(0x99000000));
        GlStateManager.pushMatrix();
        GlStateManager.translate(width / 2f, 8 - (1f - open) * 10, 0);
        GlStateManager.scale(1.6f, 1.6f, 1f);
        GlStateManager.enableBlend();
        String title = "MAX CLIENT";
        if (Theme.fade(Theme.ACCENT) >>> 24 >= 8) {
            fontRenderer.drawString(title, -fontRenderer.getStringWidth(title) / 2f, 0, Theme.fade(Theme.ACCENT), true);
        }
        GlStateManager.popMatrix();

        Category[] cats = Category.values();
        int n = cats.length;
        panelW = Math.max(80, Math.min(120, (width - GAP * (n + 1)) / n));
        int x0 = Math.max(0, (width - (n * panelW + (n - 1) * GAP)) / 2);
        int y = TOP + Math.round((1f - open) * 16f);
        for (int i = 0; i < n; i++) {
            int x = x0 + i * (panelW + GAP);
            panelX.put(cats[i], x);
            drawPanel(cats[i], x, y, panelW, mx, my);
        }
        clickBtn = -1;
    }

    private void drawPanel(Category cat, int x, int y, int w, int mx, int my) {
        List<Module> mods = ModuleManager.in(cat);
        int total = 0;
        for (Module m : mods) {
            float ex = step(expandAnim, m, expanded.contains(m) ? 1f : 0f);
            total += ROW + Math.round(settingsHeight(m) * ex);
        }
        int bodyTop = y + HEADER;
        int visible = Math.max(0, Math.min(total, height - bodyTop - 10));
        float max = Math.max(0, total - visible);
        float sc = Math.max(0f, Math.min(max, scroll.containsKey(cat) ? scroll.get(cat) : 0f));
        scroll.put(cat, sc);
        maxScroll.put(cat, max);

        Gui.drawRect(x, y, x + w, bodyTop, Theme.fade(Theme.HEADER_BG));
        RenderUtil.hGradient(x, bodyTop - 2, x + w, bodyTop, Theme.fade(Theme.ACCENT), Theme.fade(Theme.ACCENT_DARK));
        text(cat.label, x + (w - fontRenderer.getStringWidth(cat.label)) / 2, y + 6, Theme.TEXT);
        Gui.drawRect(x, bodyTop, x + w, bodyTop + visible, Theme.fade(Theme.PANEL_BG));
        int bodyBottom = bodyTop + visible;
        setClip(x, bodyTop, x + w, bodyBottom);

        int cy = bodyTop - Math.round(sc);
        for (Module m : mods) {
            drawModuleRow(m, x, cy, w, mx, my);
            int sh = Math.round(settingsHeight(m) * expandAnim.get(m));
            if (sh > 0) {
                setClip(x, Math.max(bodyTop, cy + ROW), x + w, Math.min(bodyBottom, cy + ROW + sh));
                int sy = cy + ROW;
                for (Setting s : m.settings) {
                    drawSetting(s, x, sy, w, mx, my);
                    sy += settingH(s);
                }
                setClip(x, bodyTop, x + w, bodyBottom);
            }
            cy += ROW + sh;
        }
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }

    private void drawModuleRow(Module m, int x, int y, int w, int mx, int my) {
        boolean hover = hit(mx, my, x, y, w, ROW);
        float t = step(toggleAnim, m, m.isEnabled() ? 1f : 0f);
        float h = step(hoverAnim, m, hover ? 1f : 0f);
        Gui.drawRect(x, y, x + w, y + ROW, Theme.fade(Theme.mix(Theme.ROW_BG, Theme.ROW_HOVER, h)));
        if (t > 0.01f) {
            RenderUtil.hGradient(x, y, x + w, y + ROW, Theme.fade(Theme.scaleAlpha(Theme.ACCENT, 0.6f * t)),
                    Theme.fade(Theme.scaleAlpha(Theme.ACCENT_DARK, 0.3f * t)));
            Gui.drawRect(x, y, x + 2, y + ROW, Theme.fade(Theme.scaleAlpha(Theme.ACCENT, t)));
        }
        text(m.name, x + 8, y + 4, Theme.mix(Theme.DIM, Theme.TEXT, t));
        boolean hasSettings = !m.settings.isEmpty();
        if (hasSettings) text(expanded.contains(m) ? "-" : "+", x + w - 10, y + 4, Theme.DIM);

        boolean toggleExpand = (hasSettings && clicked(0, x + w - 18, y, 18, ROW)) || (hasSettings && clicked(1, x, y, w, ROW));
        if (toggleExpand) {
            if (!expanded.remove(m)) expanded.add(m);
        } else if (clicked(0, x, y, w, ROW)) {
            m.toggle();
        }
    }

    private void drawSetting(Setting s, int x, int y, int w, int mx, int my) {
        int h = settingH(s);
        int bx = x + 8, bw = w - 16;
        Gui.drawRect(x, y, x + w, y + h, Theme.fade(Theme.SET_BG));
        text(s.name, bx, y + 3, Theme.TEXT);

        if (s instanceof BoolSetting) {
            BoolSetting b = (BoolSetting) s;
            float t = step(toggleAnim, b, b.get() ? 1f : 0f);
            int tx = x + w - 26;
            Gui.drawRect(tx, y + 3, tx + 18, y + 11, Theme.fade(Theme.mix(Theme.OFF, Theme.ACCENT, t)));
            int kx = tx + 1 + Math.round(t * 10);
            Gui.drawRect(kx, y + 4, kx + 7, y + 10, Theme.fade(Theme.TEXT));
            if (clicked(0, x, y, w, h)) b.toggle();
        } else if (s instanceof NumberSetting) {
            NumberSetting n = (NumberSetting) s;
            String v = n.display();
            text(v, x + w - 8 - fontRenderer.getStringWidth(v), y + 3, Theme.DIM);
            if (clicked(0, x, y + 10, w, h - 10)) {
                dragging = n;
                dragX = bx;
                dragW = bw;
            }
            if (dragging == n) n.set(n.min + clamp01((mx - dragX) / (float) dragW) * (n.max - n.min));
            int fx = bx + Math.round((float) ((n.get() - n.min) / (n.max - n.min)) * bw);
            int ty = y + 14;
            Gui.drawRect(bx, ty, bx + bw, ty + 4, Theme.fade(Theme.OFF));
            RenderUtil.hGradient(bx, ty, fx, ty + 4, Theme.fade(Theme.ACCENT_DARK), Theme.fade(Theme.ACCENT));
            Gui.drawRect(fx - 1, ty - 2, fx + 2, ty + 6, Theme.fade(Theme.TEXT));
        } else if (s instanceof ModeSetting) {
            ModeSetting m = (ModeSetting) s;
            String v = m.get();
            text(v, x + w - 8 - fontRenderer.getStringWidth(v), y + 3, Theme.ACCENT);
            if (clicked(0, x, y, w, h)) m.next();
            else if (clicked(1, x, y, w, h)) m.prev();
        } else if (s instanceof ColorSetting) {
            ColorSetting c = (ColorSetting) s;
            Gui.drawRect(x + w - 20, y + 3, x + w - 8, y + 11, Theme.fade(0xFF000000 | c.getRGB()));
            int hy = y + 14, sy = y + 23;
            for (int i = 0; i < 6; i++) {
                RenderUtil.hGradient(bx + bw * i / 6, hy, bx + bw * (i + 1) / 6, hy + 5,
                        Theme.fade(hsv(i / 6f, 1f)), Theme.fade(hsv((i + 1) / 6f, 1f)));
            }
            RenderUtil.hGradient(bx, sy, bx + bw, sy + 5, Theme.fade(0xFFFFFFFF), Theme.fade(hsv(c.getHue(), 1f)));
            if (clicked(0, x, y + 11, w, 9)) {
                dragging = c;
                dragBar = 0;
                dragX = bx;
                dragW = bw;
            } else if (clicked(0, x, y + 20, w, 12)) {
                dragging = c;
                dragBar = 1;
                dragX = bx;
                dragW = bw;
            }
            if (dragging == c) {
                float f = clamp01((mx - dragX) / (float) dragW);
                if (dragBar == 0) c.setHue(f); else c.setSat(f);
            }
            Gui.drawRect(bx + Math.round(c.getHue() * bw) - 1, hy - 1, bx + Math.round(c.getHue() * bw) + 2, hy + 6,
                    Theme.fade(Theme.TEXT));
            Gui.drawRect(bx + Math.round(c.getSat() * bw) - 1, sy - 1, bx + Math.round(c.getSat() * bw) + 2, sy + 6,
                    Theme.fade(Theme.TEXT));
        }
    }

    private static int settingH(Setting s) {
        return s instanceof BoolSetting || s instanceof ModeSetting ? BOOL_H : s instanceof NumberSetting ? NUM_H : COL_H;
    }

    private static int settingsHeight(Module m) {
        int h = 0;
        for (Setting s : m.settings) h += settingH(s);
        return h;
    }

    private static float clamp01(float f) { return Math.max(0f, Math.min(1f, f)); }

    private static int hsv(float h, float s) { return 0xFF000000 | MathHelper.hsvToRGB(h, s, 1f); }

    private float step(Map<Object, Float> map, Object key, float target) {
        Float cur = map.get(key);
        float v = cur == null ? target : cur;
        v += (target - v) * (1f - (float) Math.exp(-dt * 16f));
        if (Math.abs(target - v) < 0.002f) v = target;
        map.put(key, v);
        return v;
    }

    private void setClip(int x1, int y1, int x2, int y2) {
        clipX1 = x1;
        clipY1 = y1;
        clipX2 = x2;
        clipY2 = y2;
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(x1 * sf, mc.displayHeight - y2 * sf, Math.max(0, (x2 - x1) * sf), Math.max(0, (y2 - y1) * sf));
    }

    private boolean hit(int px, int py, int x, int y, int w, int h) {
        return px >= Math.max(x, clipX1) && px < Math.min(x + w, clipX2)
                && py >= Math.max(y, clipY1) && py < Math.min(y + h, clipY2);
    }

    /** True once per click if it landed on the (visible part of the) rectangle. */
    private boolean clicked(int btn, int x, int y, int w, int h) {
        if (clickBtn == btn && hit(clickX, clickY, x, y, w, h)) {
            clickBtn = -1;
            return true;
        }
        return false;
    }

    private void text(String s, int x, int y, int color) {
        int c = Theme.fade(color);
        if ((c >>> 24) < 8) return;
        GlStateManager.enableBlend();
        fontRenderer.drawString(s, x, y, c);
    }
}
