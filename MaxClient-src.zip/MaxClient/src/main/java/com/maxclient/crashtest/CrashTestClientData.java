package com.maxclient.crashtest;

/** Latest real metrics received from the server-side component; read by the Crash Test HUD module. */
public final class CrashTestClientData {
    private static volatile MetricsPacket latest;
    private static volatile long receivedAt;

    private CrashTestClientData() {}

    public static void apply(MetricsPacket p) {
        latest = p;
        receivedAt = System.currentTimeMillis();
    }

    public static void clear() {
        latest = null;
    }

    /** Null if nothing has been received yet, or the last reply is older than maxAgeMs (server stopped replying). */
    public static MetricsPacket latest(long maxAgeMs) {
        MetricsPacket p = latest;
        if (p == null || System.currentTimeMillis() - receivedAt > maxAgeMs) return null;
        return p;
    }
}
