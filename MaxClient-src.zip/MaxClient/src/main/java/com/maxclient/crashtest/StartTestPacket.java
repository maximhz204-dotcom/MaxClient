package com.maxclient.crashtest;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

/** Client -> server: "start/stop monitoring for me", with a sampling period and a duration cap. */
public class StartTestPacket implements IMessage {
    public boolean start;
    public int intervalTicks;
    public int durationSeconds;

    public StartTestPacket() {}

    public StartTestPacket(boolean start, int intervalTicks, int durationSeconds) {
        this.start = start;
        this.intervalTicks = intervalTicks;
        this.durationSeconds = durationSeconds;
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeBoolean(start);
        buf.writeInt(intervalTicks);
        buf.writeInt(durationSeconds);
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        start = buf.readBoolean();
        intervalTicks = buf.readInt();
        durationSeconds = buf.readInt();
    }
}
