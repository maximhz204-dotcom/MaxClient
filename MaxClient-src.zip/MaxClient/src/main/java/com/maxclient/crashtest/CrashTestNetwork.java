package com.maxclient.crashtest;

import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

/** One small channel, two tiny packets: a start/stop request and a periodic metrics reply. No other traffic. */
public final class CrashTestNetwork {
    public static final SimpleNetworkWrapper CHANNEL =
            NetworkRegistry.INSTANCE.newSimpleChannel("maxclient_ct");

    private CrashTestNetwork() {}

    public static void init() {
        CHANNEL.registerMessage(ServerHandler.class, StartTestPacket.class, 0, Side.SERVER);
        CHANNEL.registerMessage(ClientHandler.class, MetricsPacket.class, 1, Side.CLIENT);
    }

    public static final class ServerHandler implements IMessageHandler<StartTestPacket, IMessage> {
        @Override
        public IMessage onMessage(StartTestPacket msg, MessageContext ctx) {
            final net.minecraft.entity.player.EntityPlayerMP player = ctx.getServerHandler().player;
            player.getServerWorld().addScheduledTask(new Runnable() {
                @Override public void run() { CrashTestServer.handle(player, msg); }
            });
            return null;
        }
    }

    public static final class ClientHandler implements IMessageHandler<MetricsPacket, IMessage> {
        @Override
        public IMessage onMessage(MetricsPacket msg, MessageContext ctx) {
            CrashTestClientData.apply(msg);
            return null;
        }
    }
}
