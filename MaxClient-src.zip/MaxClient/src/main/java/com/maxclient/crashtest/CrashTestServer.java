package com.maxclient.crashtest;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.lang.management.ManagementFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Server-side (and, for singleplayer, integrated-server) monitoring. Pure measurement: it never generates any
 * workload or extra traffic. TPS/MSPT come from real time between actual server ticks (TickEvent.ServerTickEvent,
 * the same safe pattern used for the client's own TPS reading). CPU/RAM come from the standard JVM APIs
 * (java.lang.management, Runtime) - never fabricated. Requires server-operator permission (vanilla op level 2)
 * to start, and auto-stops after its configured duration or a hard safety cap, whichever comes first.
 */
public final class CrashTestServer {
    private static final int HARD_CAP_SECONDS = 120;

    private static final class Session {
        int intervalTicks;
        int remainingTicks;
        int sinceLast;
    }

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();
    private static float lastTickMs = 50f;
    private static long lastTickAt = -1L;

    private CrashTestServer() {}

    public static void init() {
        MinecraftForge.EVENT_BUS.register(new Object() {
            @SubscribeEvent
            public void onServerTick(TickEvent.ServerTickEvent e) {
                if (e.phase != TickEvent.Phase.END) return;
                long now = System.currentTimeMillis();
                if (lastTickAt > 0) lastTickMs += ((now - lastTickAt) - lastTickMs) * 0.1f;
                lastTickAt = now;
                tickSessions();
            }
        });
    }

    /** Validates permission, then starts or stops this player's monitoring session. */
    public static void handle(EntityPlayerMP player, StartTestPacket msg) {
        if (!player.canUseCommand(2, "crashtest")) {
            CrashTestNetwork.CHANNEL.sendTo(new MetricsPacket(-1, -1, -1, 0, 0, false), player);
            return;
        }
        if (!msg.start) {
            SESSIONS.remove(player.getUniqueID());
            CrashTestNetwork.CHANNEL.sendTo(new MetricsPacket(-1, -1, -1, 0, 0, false), player);
            return;
        }
        Session s = new Session();
        s.intervalTicks = Math.max(5, msg.intervalTicks);
        s.remainingTicks = Math.min(msg.durationSeconds, HARD_CAP_SECONDS) * 20;
        SESSIONS.put(player.getUniqueID(), s);
        sendMetrics(player, true);
    }

    private static void tickSessions() {
        if (SESSIONS.isEmpty()) return;
        for (java.util.Iterator<Map.Entry<UUID, Session>> it = SESSIONS.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Session> e = it.next();
            Session s = e.getValue();
            boolean finished = --s.remainingTicks <= 0;
            if (++s.sinceLast >= s.intervalTicks || finished) {
                s.sinceLast = 0;
                EntityPlayerMP p = net.minecraftforge.fml.common.FMLCommonHandler.instance()
                        .getMinecraftServerInstance().getPlayerList().getPlayerByUUID(e.getKey());
                if (p != null) sendMetrics(p, !finished);
            }
            if (finished) it.remove();
        }
    }

    private static void sendMetrics(EntityPlayerMP player, boolean active) {
        float tps = Math.max(0f, Math.min(20f, 1000f / Math.max(1f, lastTickMs)));
        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
        long maxMb = rt.maxMemory() / (1024 * 1024);
        double load = ManagementFactory.getOperatingSystemMXBean().getSystemLoadAverage();
        CrashTestNetwork.CHANNEL.sendTo(new MetricsPacket(tps, lastTickMs, load, usedMb, maxMb, active), player);
    }
}
