package com.maxclient.crashtest;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

/** Server -> client: one real sample. Every field is an actual measurement, never invented. */
public class MetricsPacket implements IMessage {
    public float tps;
    public float msptMs;
    public double sysLoad;
    public long usedMb, maxMb;
    public boolean active;

    public MetricsPacket() {}

    public MetricsPacket(float tps, float msptMs, double sysLoad, long usedMb, long maxMb, boolean active) {
        this.tps = tps;
        this.msptMs = msptMs;
        this.sysLoad = sysLoad;
        this.usedMb = usedMb;
        this.maxMb = maxMb;
        this.active = active;
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeFloat(tps);
        buf.writeFloat(msptMs);
        buf.writeDouble(sysLoad);
        buf.writeLong(usedMb);
        buf.writeLong(maxMb);
        buf.writeBoolean(active);
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        tps = buf.readFloat();
        msptMs = buf.readFloat();
        sysLoad = buf.readDouble();
        usedMb = buf.readLong();
        maxMb = buf.readLong();
        active = buf.readBoolean();
    }
}
