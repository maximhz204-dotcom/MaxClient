package com.maxclient.friend;

import com.maxclient.config.ConfigManager;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

import java.util.List;
import java.util.Locale;

/** Client command: /friend add|remove|list|clear [name]. */
public class FriendCommand extends CommandBase {
    @Override public String getName() { return "friend"; }

    @Override public String getUsage(ICommandSender sender) { return "/friend <add|remove|list|clear> [name]"; }

    @Override public int getRequiredPermissionLevel() { return 0; }

    @Override public boolean checkPermission(MinecraftServer server, ICommandSender sender) { return true; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) {
            say(sender, getUsage(sender));
            return;
        }
        String action = args[0].toLowerCase(Locale.ROOT);
        if (action.equals("list")) {
            List<String> l = FriendManager.list();
            say(sender, l.isEmpty() ? "Friends: none" : "Friends: " + String.join(", ", l));
        } else if (action.equals("clear")) {
            FriendManager.clear();
            ConfigManager.save();
            say(sender, "Friend list cleared");
        } else if (args.length >= 2 && action.equals("add")) {
            say(sender, FriendManager.add(args[1]) ? "Added friend " + args[1] : args[1] + " is already a friend");
            ConfigManager.save();
        } else if (args.length >= 2 && action.equals("remove")) {
            say(sender, FriendManager.remove(args[1]) ? "Removed friend " + args[1] : args[1] + " is not a friend");
            ConfigManager.save();
        } else {
            say(sender, getUsage(sender));
        }
    }

    private static void say(ICommandSender sender, String text) {
        sender.sendMessage(new TextComponentString("[MAX CLIENT] " + text));
    }
}
