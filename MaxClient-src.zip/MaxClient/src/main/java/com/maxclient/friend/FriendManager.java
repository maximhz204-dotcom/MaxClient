package com.maxclient.friend;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Friend names (case-insensitive). Saved together with the rest of the config. */
public final class FriendManager {
    private static final Set<String> FRIENDS = new LinkedHashSet<>();

    private FriendManager() {}

    public static boolean isFriend(String name) {
        return FRIENDS.contains(name.toLowerCase(Locale.ROOT));
    }

    public static boolean add(String name) {
        return FRIENDS.add(name.toLowerCase(Locale.ROOT));
    }

    public static boolean remove(String name) {
        return FRIENDS.remove(name.toLowerCase(Locale.ROOT));
    }

    public static void clear() {
        FRIENDS.clear();
    }

    public static List<String> list() {
        return new ArrayList<>(FRIENDS);
    }
}
